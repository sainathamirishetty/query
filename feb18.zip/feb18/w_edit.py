"""
WEB SERVER MODIFICATIONS FOR MEETING QUERIES FEATURE

INSTRUCTIONS:
1. Open your web_server_192_with_login.py
2. Follow the markers below to add code at specific locations
"""


# ============================================================================
# SECTION 1 — ADD NEW LOG FUNCTIONS
# Location: After your existing log functions (log_discussion_summary_upload, etc.)
#          BEFORE job_metadata = {}
# ============================================================================

def log_meeting_queries_access(ip: str, username: str):
    """Log Meeting Queries page access"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | User: {username}"
    write_log(log_message)


def log_session_selected_for_query(ip: str, username: str, session_name: str):
    """Log when user selects a session for querying"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: Session Selected | Session: {session_name} | User: {username}"
    write_log(log_message)


def log_task_selected_for_query(ip: str, username: str, task_name: str, session_count: int):
    """Log when user selects a task for querying"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: Task Selected | Task: {task_name} | Sessions Selected: {session_count} | User: {username}"
    write_log(log_message)


def log_question_asked(ip: str, username: str, mode: str, context: str, question: str):
    """Log when user asks a question"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # Truncate question if too long
    question_display = question[:100] + "..." if len(question) > 100 else question
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: Question Asked | Mode: {mode} | Context: {context} | Question: {question_display} | User: {username}"
    write_log(log_message)


def log_answer_generated(ip: str, username: str, mode: str, matched_sessions: str, status: str):
    """Log answer generation result"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: Answer Generated | Mode: {mode} | Matched Sessions: {matched_sessions} | Status: {status} | User: {username}"
    write_log(log_message)


def log_global_summary_viewed(ip: str, username: str, session_name: str):
    """Log when user views global summary"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: Global Summary Viewed | Session: {session_name} | User: {username}"
    write_log(log_message)


def log_no_global_summary_found(ip: str, username: str, session_name: str):
    """Log when global summary doesn't exist for selected session"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: No Global Summary | Session: {session_name} | User: {username}"
    write_log(log_message)


def log_global_summary_auto_generated(ip: str, username: str, session_name: str, result_count: int):
    """Log when global summary is auto-generated after meeting"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Discussion Summary | Action: Global Summary Auto-Generated | Session: {session_name} | Results: {result_count} | User: {username}"
    write_log(log_message)


# ============================================================================
# SECTION 2 — ADD MEETING QUERIES HTML ROUTE
# Location: After @app.get("/Discussion_Summary.html")
#          BEFORE @app.get("/health")
# ============================================================================

@app.get("/Meeting_Queries.html", response_class=HTMLResponse)
async def serve_meeting_queries(request: Request, user: dict = Depends(require_auth)):
    """Serve the Meeting Queries page - PROTECTED"""
    try:
        client_ip = get_client_ip(request)
        log_meeting_queries_access(client_ip, user['username'])

        with open("Meeting_Queries.html", "r", encoding="utf-8") as f:
            html_content = f.read()

        # Inject user info
        user_info_html = f"""
        <div style="position: fixed; top: 20px; right: 20px; background: rgba(255,255,255,0.9); 
                    padding: 10px 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);
                    z-index: 1000;">
            <span style="color: #333; font-weight: 600;">{user['display_name']}</span>
            <a href="/logout" style="margin-left: 15px; color: #667eea; text-decoration: none; 
                                     font-weight: 600;">Logout</a>
        </div>
        """
        html_content = html_content.replace("</body>", f"{user_info_html}</body>")

        return HTMLResponse(content=html_content)
    except FileNotFoundError:
        return HTMLResponse(
            content="<h1>Error: Meeting_Queries.html not found</h1>",
            status_code=404
        )


# ============================================================================
# SECTION 3 — ADD Q&A PROXY ENDPOINTS
# Location: After all your existing proxy endpoints (delete_discussion_session_proxy, etc.)
#          BEFORE @app.exception_handler(401)
# ============================================================================

@app.get("/check_global_summary/{session_id}")
async def check_global_summary_proxy(
        request: Request,
        session_id: str,
        user: dict = Depends(require_auth)
):
    """Check if global summary exists for session"""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f"{GPU_SERVER_URL}/check_global_summary/{session_id}")
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error checking global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/get_global_summary/{session_id}")
async def get_global_summary_proxy(
        request: Request,
        session_id: str,
        user: dict = Depends(require_auth)
):
    """Get global summary for session"""
    try:
        client_ip = get_client_ip(request)

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f"{GPU_SERVER_URL}/get_global_summary/{session_id}")

            if response.status_code == 200:
                data = response.json()
                # Log viewing if successful
                log_global_summary_viewed(client_ip, user['username'], session_id[:8])
                return data
            elif response.status_code == 404:
                log_no_global_summary_found(client_ip, user['username'], session_id[:8])
                raise HTTPException(status_code=404, detail="Global summary not found")
            else:
                raise HTTPException(status_code=response.status_code, detail=response.text)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Error getting global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ask_question")
async def ask_question_proxy(
        request: Request,
        user: dict = Depends(require_auth)
):
    """Forward Q&A request to GPU server"""
    try:
        client_ip = get_client_ip(request)
        body = await request.json()

        question = body.get('question', '')
        session_ids = body.get('session_ids', [])
        context_name = body.get('context_name', 'Unknown')

        # Determine mode
        mode = "Single Session" if len(session_ids) == 1 else "Multi Session"

        # Log question asked
        log_question_asked(client_ip, user['username'], mode, context_name, question)

        async with httpx.AsyncClient(timeout=120.0) as client:
            response = await client.post(
                f"{GPU_SERVER_URL}/ask_question",
                json=body
            )

            if response.status_code == 200:
                data = response.json()

                # Extract matched session names for logging
                source_sessions = data.get('source_sessions', [])
                matched_names = ", ".join([s['session_name'] for s in source_sessions])

                # Log successful answer generation
                log_answer_generated(client_ip, user['username'], mode, matched_names, "SUCCESS")

                return data
            else:
                log_answer_generated(client_ip, user['username'], mode, "N/A", "FAILED")
                raise HTTPException(status_code=response.status_code, detail=response.text)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Error in Q&A: {str(e)}")
        log_answer_generated(get_client_ip(request), user['username'], "Unknown", "N/A", "ERROR")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/save_global_summary_auto")
async def save_global_summary_auto_proxy(
        request: Request,
        user: dict = Depends(require_auth)
):
    """Save global summary after auto-generation"""
    try:
        body = await request.json()

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{GPU_SERVER_URL}/save_global_summary",
                json=body
            )
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error saving global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# END OF WEB SERVER MODIFICATIONS
# ============================================================================