"""
GPU SERVER MODIFICATIONS FOR MEETING QUERIES FEATURE

INSTRUCTIONS:
1. Open your gpu_server_83_nosave.py
2. Follow the markers below to add code at specific locations
3. Some sections REPLACE existing code - marked clearly
"""

# ============================================================================
# SECTION 1 — ADD THESE IMPORTS
# Location: After your existing imports, before Configuration section
# ============================================================================

from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
from sentence_transformers import SentenceTransformer
import numpy as np
import json  # CRITICAL - Don't forget this
from typing import Optional, List

# ============================================================================
# SECTION 2 — ADD THESE CONFIGURATIONS
# Location: After RECORDINGS_DIR, before model variables (model = None)
# ============================================================================

# Q&A Configuration
QA_MODEL_PATH = "/path/to/your/Mistral-7B-Instruct-v0.3"  # UPDATE THIS PATH
EMBED_MODEL_PATH = "/path/to/your/all-MiniLM-L6-v2"  # UPDATE THIS PATH

# Global variables for Q&A models (add these alongside existing model variables)
qa_model = None
qa_tokenizer = None
embed_model = None


# ============================================================================
# SECTION 3 — MODIFY initialize_database() FUNCTION
# Location: Find your existing initialize_database() function
# Action: ADD this new table creation AFTER your existing results table
# ============================================================================

def initialize_database():
    """Initialize database for task hierarchy"""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    # Tasks table (existing - DON'T CHANGE)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            task_id TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            task_name TEXT NOT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL
        )
    """)

    # Sessions table (existing - DON'T CHANGE)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            session_id TEXT PRIMARY KEY,
            task_id TEXT,
            username TEXT NOT NULL,
            session_name TEXT NOT NULL,
            session_number INTEGER,
            meeting_date TEXT,
            meeting_time TEXT,
            venue TEXT,
            agenda TEXT,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            FOREIGN KEY (task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
        )
    """)

    # Results table (existing - DON'T CHANGE)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS results (
            result_id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            result_order INTEGER NOT NULL,
            mode TEXT NOT NULL,
            summary_length TEXT,
            result_text TEXT NOT NULL,
            created_at DATETIME NOT NULL,
            FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE CASCADE
        )
    """)

    # ===== ADD THIS NEW TABLE =====
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS global_summaries (
            summary_id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            summary_text TEXT NOT NULL,
            embedding TEXT,
            is_auto_generated BOOLEAN DEFAULT 1,
            created_at DATETIME NOT NULL,
            is_latest BOOLEAN DEFAULT 1,
            FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE CASCADE
        )
    """)

    conn.commit()
    conn.close()
    logger.info("✓ Database initialized")


# ============================================================================
# SECTION 4 — ADD NEW HELPER FUNCTIONS
# Location: After your existing session management functions (like delete_session)
#          BEFORE the @asynccontextmanager lifespan function
# ============================================================================

def save_global_summary_to_db(session_id: str, summary_text: str, is_auto: bool = True):
    """Save global summary with optional embedding to database"""
    summary_id = str(uuid.uuid4())
    now = datetime.now().isoformat()

    # Generate embedding if embed_model is loaded
    embedding_json = None
    if embed_model is not None:
        try:
            embedding = embed_model.encode(summary_text)
            embedding_json = json.dumps(embedding.tolist())
            logger.info(f"✓ Generated embedding for session {session_id[:8]}...")
        except Exception as e:
            logger.warning(f"⚠ Could not generate embedding: {str(e)}")

    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        # Mark previous summaries as not latest
        cursor.execute("""
            UPDATE global_summaries 
            SET is_latest = 0 
            WHERE session_id = ?
        """, (session_id,))

        # Insert new summary
        cursor.execute("""
            INSERT INTO global_summaries 
            (summary_id, session_id, summary_text, embedding, is_auto_generated, created_at, is_latest)
            VALUES (?, ?, ?, ?, ?, ?, 1)
        """, (summary_id, session_id, summary_text, embedding_json, is_auto, now))

        conn.commit()
        conn.close()

    logger.info(f"✓ Saved global summary for session {session_id[:8]}...")
    return summary_id


def get_global_summary_from_db(session_id: str):
    """Get latest global summary for a session"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT summary_id, summary_text, embedding, created_at
            FROM global_summaries
            WHERE session_id = ? AND is_latest = 1
            ORDER BY created_at DESC
            LIMIT 1
        """, (session_id,))

        result = cursor.fetchone()
        conn.close()

        if result:
            return {
                'summary_id': result[0],
                'summary_text': result[1],
                'embedding': result[2],
                'created_at': result[3]
            }
        return None


def get_multiple_summaries_with_embeddings(session_ids: List[str]):
    """Get global summaries for multiple sessions with embeddings"""
    summaries = []

    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        for session_id in session_ids:
            cursor.execute("""
                SELECT s.session_id, s.session_name, gs.summary_text, gs.embedding
                FROM global_summaries gs
                JOIN sessions s ON gs.session_id = s.session_id
                WHERE gs.session_id = ? AND gs.is_latest = 1
            """, (session_id,))

            result = cursor.fetchone()
            if result:
                sid, session_name, summary_text, embedding_json = result

                # Generate embedding if not exists
                if not embedding_json and embed_model is not None:
                    try:
                        embedding = embed_model.encode(summary_text)
                        embedding_json = json.dumps(embedding.tolist())

                        # Save embedding back to DB
                        cursor.execute("""
                            UPDATE global_summaries
                            SET embedding = ?
                            WHERE session_id = ? AND is_latest = 1
                        """, (embedding_json, sid))
                        conn.commit()
                        logger.info(f"✓ Generated embedding for {session_name}")
                    except Exception as e:
                        logger.error(f"✗ Embedding error: {str(e)}")
                        continue

                if embedding_json:
                    summaries.append({
                        'session_id': sid,
                        'session_name': session_name,
                        'summary_text': summary_text,
                        'embedding': np.array(json.loads(embedding_json))
                    })

        conn.close()

    return summaries


def find_best_matching_summary(question: str, summaries: List[dict], threshold: float = 0.3):
    """Find best matching summary using cosine similarity"""
    if not embed_model or not summaries:
        return None

    try:
        # Encode question
        question_embedding = embed_model.encode(question)

        # Calculate similarities
        best_match = None
        best_score = -1

        for summary in summaries:
            similarity = np.dot(question_embedding, summary['embedding']) / (
                    np.linalg.norm(question_embedding) * np.linalg.norm(summary['embedding'])
            )

            if similarity > best_score:
                best_score = similarity
                best_match = summary

        logger.info(f"✓ Best match score: {best_score:.3f}")

        # If score too low, return multiple summaries
        if best_score < threshold:
            logger.info(f"⚠ Low confidence, returning top 2 summaries")
            sorted_summaries = sorted(summaries,
                                      key=lambda x: np.dot(question_embedding, x['embedding']),
                                      reverse=True)
            return sorted_summaries[:2]  # Return top 2

        return [best_match]

    except Exception as e:
        logger.error(f"✗ Matching error: {str(e)}")
        return summaries[:1]  # Fallback to first summary


def generate_qa_answer(context_summaries: List[dict], question: str) -> str:
    """Generate answer using Mistral 7B"""
    if not qa_model or not qa_tokenizer:
        raise Exception("Q&A model not loaded")

    # Combine summaries if multiple
    if len(context_summaries) > 1:
        combined_context = "\n\n=== MEETING SUMMARIES ===\n\n"
        for idx, summary in enumerate(context_summaries, 1):
            combined_context += f"Session {idx}: {summary['session_name']}\n{summary['summary_text']}\n\n"
    else:
        combined_context = context_summaries[0]['summary_text']

    # Build prompt
    messages = [
        {
            "role": "system",
            "content": """You are a meeting assistant for a government department. 
Answer questions ONLY from the provided meeting summary.
Do not use any outside knowledge.
If the answer is not in the summary, say "This was not discussed in the meeting."
Be concise, factual, and direct."""
        },
        {
            "role": "user",
            "content": f"""MEETING SUMMARY:
{combined_context}

QUESTION:
{question}

ANSWER:"""
        }
    ]

    # Format with chat template
    formatted = qa_tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    # Tokenize
    inputs = qa_tokenizer(formatted, return_tensors="pt").to(device)

    # Generate
    outputs = qa_model.generate(
        **inputs,
        max_new_tokens=512,
        temperature=0.1,
        do_sample=False,
        repetition_penalty=1.1,
        pad_token_id=qa_tokenizer.eos_token_id
    )

    # Decode
    answer = qa_tokenizer.decode(
        outputs[0][inputs.input_ids.shape[1]:],
        skip_special_tokens=True
    )

    return answer.strip()


# ============================================================================
# SECTION 5 — REPLACE ENTIRE lifespan FUNCTION
# Location: Find @asynccontextmanager async def lifespan(app: FastAPI):
# Action: REPLACE the entire function with this
# ============================================================================

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global model, processor
    global qa_model, qa_tokenizer, embed_model

    try:
        # Set offline mode FIRST
        os.environ['TRANSFORMERS_OFFLINE'] = '1'
        os.environ['HF_DATASETS_OFFLINE'] = '1'

        # Initialize database first
        initialize_database()

        logger.info("=" * 70)
        logger.info("Loading AI models...")
        logger.info("=" * 70)

        # Load Voxtral (existing - unchanged)
        repo_id = "/Users/vishnukumarkudidela/Desktop/workspace/ASR/models/Voxtral-Mini-3B-2507"
        processor = AutoProcessor.from_pretrained(repo_id)
        model = VoxtralForConditionalGeneration.from_pretrained(
            repo_id, torch_dtype=torch.bfloat16, device_map=device
        )
        logger.info(f"✓ Voxtral loaded successfully on {device}")

        # Load Q&A Models (NEW)
        try:
            # Load Mistral 7B with 4-bit quantization
            logger.info("Loading Mistral 7B for Q&A...")
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.bfloat16
            )

            qa_tokenizer = AutoTokenizer.from_pretrained(
                QA_MODEL_PATH,
                local_files_only=True
            )
            qa_model = AutoModelForCausalLM.from_pretrained(
                QA_MODEL_PATH,
                quantization_config=quantization_config,
                device_map=device,
                local_files_only=True
            )
            logger.info("✓ Mistral 7B loaded successfully")

            # Load embedding model
            logger.info("Loading embedding model...")
            embed_model = SentenceTransformer(EMBED_MODEL_PATH)
            logger.info("✓ Embedding model loaded successfully")

        except Exception as e:
            logger.error(f"✗ Failed to load Q&A models: {e}")
            logger.warning("⚠ Q&A features will not be available")

        logger.info("=" * 70)

    except Exception as e:
        logger.error(f"✗ Failed to load models: {e}")
        raise

    yield

    # Shutdown
    logger.info("Shutting down GPU server...")


# ============================================================================
# SECTION 6 — REPLACE /global_summary ENDPOINT
# Location: Find @app.post("/global_summary")
# Action: REPLACE entire endpoint function with this
# ============================================================================

@app.post("/global_summary")
async def generate_global_summary(request: GlobalSummaryRequest):
    """Generate a global summary from multiple text results"""
    if not model or not processor:
        raise HTTPException(status_code=503, detail="Model not loaded")

    if not request.texts:
        raise HTTPException(status_code=400, detail="No texts provided")

    try:
        # Filter out transcriptions, keep only summaries and action points
        filtered = [t for t in request.texts if not t.strip().startswith("[TRANSCRIPTION]")]

        if not filtered:
            raise HTTPException(status_code=400, detail="No valid summaries or action points to process")

        combined = "\n\n".join(filtered)

        conversation = [{
            "role": "user",
            "content": [{
                "type": "text",
                "text": (
                    "You are an expert meeting summarizer. Your task is to create a comprehensive global summary "
                    "from multiple meeting segments.\n\n"

                    "INSTRUCTIONS:\n"
                    "1. Read and analyze all the provided text segments carefully\n"
                    "2. Identify and group related topics across all segments\n"
                    "3. Create a cohesive, well-organized summary that covers ALL topics discussed\n"
                    "4. Maintain chronological flow when relevant\n"
                    "5. Preserve important details, decisions, and discussions\n"
                    "6. Remove redundancies while keeping unique information from each segment\n"
                    "7. don't repeat the sentences keep as unique\n\n"

                    "OUTPUT STRUCTURE:\n"
                    "- Start with an 'OVERVIEW' section (2-3 sentences about the overall meeting)\n"
                    "- Organize content by TOPICS with clear headings\n"
                    "- Under each topic, provide key points and discussions\n"
                    "- Include a 'KEY DECISIONS' section if any decisions were made\n"
                    "- End with 'ACTION ITEMS' section if action points exist\n\n"

                    "IMPORTANT GUIDELINES:\n"
                    "- Do NOT add information not present in the original text\n"
                    "- Do NOT miss any important topics, even if briefly mentioned\n"
                    "- Use clear, professional language\n"
                    "- Be concise but comprehensive\n"
                    "- don't repeat the sentences keep as unique\n"
                    "- don't add action points twice in global summary\n"
                    "- If a topic appears in multiple segments, consolidate it intelligently\n\n"

                    f"TEXT TO SUMMARIZE:\n\n{combined}"
                )
            }]
        }]

        inputs = processor.apply_chat_template(conversation)
        inputs = inputs.to(device, dtype=torch.bfloat16)
        outputs = model.generate(
            **inputs,
            max_new_tokens=4096,
            temperature=0.1,
            top_p=0.85,
            do_sample=False,
            repetition_penalty=1.1
        )
        decoded = processor.batch_decode(
            outputs[:, inputs.input_ids.shape[1]:],
            skip_special_tokens=True
        )

        global_summary_text = decoded[0]

        logger.info("✓ Global summary generated successfully")

        # NOTE: This endpoint now only generates
        # Saving to DB happens via separate /save_global_summary endpoint
        # called from frontend

        return {
            "status": "success",
            "global_summary": global_summary_text
        }

    except Exception as e:
        logger.error(f"✗ Global summary generation failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# SECTION 7 — ADD NEW Q&A ENDPOINTS
# Location: After all your existing endpoints, BEFORE if __name__ == "__main__"
# ============================================================================

@app.get("/check_global_summary/{session_id}")
async def check_global_summary_exists(session_id: str):
    """Check if global summary exists for a session"""
    try:
        summary = get_global_summary_from_db(session_id)
        return {
            "status": "success",
            "exists": summary is not None
        }
    except Exception as e:
        logger.error(f"✗ Error checking global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/get_global_summary/{session_id}")
async def get_global_summary_endpoint(session_id: str):
    """Get global summary for a session"""
    try:
        summary = get_global_summary_from_db(session_id)

        if not summary:
            raise HTTPException(status_code=404, detail="Global summary not found")

        return {
            "status": "success",
            "summary": summary
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Error getting global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ask_question")
async def ask_question_endpoint(request: Request):
    """Answer question from meeting context"""
    try:
        body = await request.json()
        question = body.get('question', '').strip()
        session_ids = body.get('session_ids', [])

        if not question:
            raise HTTPException(status_code=400, detail="Question is required")

        if not session_ids or len(session_ids) == 0:
            raise HTTPException(status_code=400, detail="At least one session required")

        logger.info(f"📝 Q&A Request - Question: '{question[:50]}...' - Sessions: {len(session_ids)}")

        # Single session - direct fetch
        if len(session_ids) == 1:
            summary = get_global_summary_from_db(session_ids[0])

            if not summary:
                raise HTTPException(status_code=404, detail="Global summary not found for this session")

            # Get session name
            with db_lock:
                conn = sqlite3.connect(DB_FILE)
                cursor = conn.cursor()
                cursor.execute("SELECT session_name FROM sessions WHERE session_id = ?", (session_ids[0],))
                result = cursor.fetchone()
                conn.close()
                session_name = result[0] if result else "Unknown Session"

            context = [{
                'session_id': session_ids[0],
                'session_name': session_name,
                'summary_text': summary['summary_text'],
                'embedding': None
            }]

            logger.info(f"✓ Single session mode - Direct fetch")

        # Multiple sessions - embedding match
        else:
            summaries = get_multiple_summaries_with_embeddings(session_ids)

            if not summaries:
                raise HTTPException(status_code=404, detail="No global summaries found for selected sessions")

            # Find best matching summaries
            context = find_best_matching_summary(question, summaries)

            if not context:
                raise HTTPException(status_code=500, detail="Could not find relevant context")

            logger.info(f"✓ Multi session mode - Matched {len(context)} summary(ies)")

        # Generate answer
        answer = generate_qa_answer(context, question)

        # Prepare attribution
        if len(context) == 1:
            attribution = context[0]['session_name']
        else:
            attribution = " + ".join([s['session_name'] for s in context])

        logger.info(f"✓ Answer generated - Source: {attribution}")

        return {
            "status": "success",
            "answer": answer,
            "source_sessions": [
                {
                    'session_id': s['session_id'],
                    'session_name': s['session_name']
                }
                for s in context
            ]
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Q&A Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/save_global_summary")
async def save_global_summary_endpoint(request: Request):
    """Save global summary to database (called after auto-generation)"""
    try:
        body = await request.json()
        session_id = body.get('session_id')
        summary_text = body.get('summary_text')
        is_auto = body.get('is_auto_generated', True)

        if not session_id or not summary_text:
            raise HTTPException(status_code=400, detail="session_id and summary_text required")

        summary_id = save_global_summary_to_db(session_id, summary_text, is_auto)

        return {
            "status": "success",
            "summary_id": summary_id
        }
    except Exception as e:
        logger.error(f"✗ Error saving global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# END OF GPU SERVER MODIFICATIONS
# ============================================================================