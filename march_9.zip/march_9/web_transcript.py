from fastapi import FastAPI, File, UploadFile, Form, HTTPException, Request, Response, Depends, Cookie
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Optional
import uvicorn
import httpx
import logging
from pathlib import Path
from datetime import datetime, timedelta
import os
import secrets
import sqlite3
from threading import Lock
import re
from urllib.parse import quote

# LDAP imports
#from ldap3 import Server, Connection, ALL, SIMPLE, SUBTREE
#from ldap3.core.exceptions import LDAPException

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
GPU_SERVER_URL = "http://127.0.0.1:8001"  # GPU processing server
LOGS_DIR = Path("./logs")
LOGS_DIR.mkdir(exist_ok=True)
DB_FILE = Path("./auth_sessions.db")
SESSION_TIMEOUT = 7200  # 2 hours in seconds

# Database lock
db_lock = Lock()

app = FastAPI(title="DEAIS MOM Server", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
#app.mount("/mom_icons", StaticFiles(directory="mom_icons"), name="mom_icons")
#app.mount("/public", StaticFiles(directory="public"), name="public")


class GlobalSummaryRequest(BaseModel):
    texts: List[str]
    session_id: Optional[str] = None   # forwarded to gpu server for server-side save


# ============================================================================
# DATABASE INITIALIZATION
# ============================================================================

def initialize_auth_database():
    """Initialize SQLite database for session management"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        # Sessions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_token TEXT PRIMARY KEY,
                username TEXT NOT NULL,
                display_name TEXT NOT NULL,
                created_at DATETIME NOT NULL,
                last_activity DATETIME NOT NULL,
                ip_address TEXT
            )
        """)

        # Local users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS local_users (
                username TEXT PRIMARY KEY,
                password TEXT NOT NULL,
                display_name TEXT NOT NULL,
                created_at DATETIME NOT NULL
            )
        """)

        conn.commit()

        # Add default users if table is empty
        cursor.execute("SELECT COUNT(*) FROM local_users")
        if cursor.fetchone()[0] == 0:
            default_users = [
                ("admin", "admin123", "Administrator"),
                ("john", "pass123", "John Doe"),
                ("jane", "pass456", "Jane Smith"),
                ("dlpda", "dl@209", "DLPDA"),

            ]

            for username, password, display_name in default_users:
                cursor.execute("""
                    INSERT INTO local_users (username, password, display_name, created_at)
                    VALUES (?, ?, ?, ?)
                """, (username, password, display_name, datetime.now().isoformat()))

            conn.commit()
            logger.info(f"✓ Created {len(default_users)} default users")

        conn.close()


def cleanup_expired_sessions():
    """Remove expired sessions from database"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        expiry_time = (datetime.now() - timedelta(seconds=SESSION_TIMEOUT)).isoformat()
        cursor.execute("DELETE FROM sessions WHERE last_activity < ?", (expiry_time,))
        conn.commit()
        conn.close()


def create_session(username: str, display_name: str, ip_address: str) -> str:
    """Create a new session and return session token"""
    session_token = secrets.token_urlsafe(32)
    now = datetime.now().isoformat()
    
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO sessions (session_token, username, display_name, created_at, last_activity, ip_address)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (session_token, username, display_name, now, now, ip_address))
        conn.commit()
        conn.close()
    
    return session_token


def validate_session(session_token: str) -> Optional[dict]:
    """Validate session token and return user data if valid"""
    if not session_token:
        return None
    
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT username, display_name, last_activity 
            FROM sessions 
            WHERE session_token = ?
        """, (session_token,))
        result = cursor.fetchone()
        
        if result:
            username, display_name, last_activity = result
            last_activity_dt = datetime.fromisoformat(last_activity)
            
            # Check if session expired
            if datetime.now() - last_activity_dt > timedelta(seconds=SESSION_TIMEOUT):
                cursor.execute("DELETE FROM sessions WHERE session_token = ?", (session_token,))
                conn.commit()
                conn.close()
                return None
            
            # Update last activity
            cursor.execute("""
                UPDATE sessions 
                SET last_activity = ? 
                WHERE session_token = ?
            """, (datetime.now().isoformat(), session_token))
            conn.commit()
            conn.close()
            
            return {
                "username": username,
                "display_name": display_name
            }
        
        conn.close()
        return None


def delete_session(session_token: str):
    """Delete a session (logout)"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM sessions WHERE session_token = ?", (session_token,))
        conn.commit()
        conn.close()


# ============================================================================
# LDAP AUTHENTICATION
# ============================================================================

def authenticate_local_user(username: str, password: str, client_ip: str):
    """
    Simple authentication against local database
    """
    try:
        with db_lock:
            conn = sqlite3.connect(DB_FILE)
            cursor = conn.cursor()

            cursor.execute("""
                SELECT password, display_name 
                FROM local_users 
                WHERE username = ?
            """, (username,))

            result = cursor.fetchone()
            conn.close()

            if result:
                stored_password, display_name = result
                if password == stored_password:
                    logger.info(f"✓ Login Success: {username} ({display_name}) from {client_ip}")
                    return True, display_name
                else:
                    logger.warning(f"✗ Login Failed: {username} - Wrong password from {client_ip}")
                    return False, "Invalid password"
            else:
                logger.warning(f"✗ Login Failed: {username} - User not found from {client_ip}")
                return False, "User not found"

    except Exception as e:
        logger.error(f"✗ Auth Error: {username} - {str(e)}")
        return False, f"Authentication error: {str(e)}"


# ============================================================================
# SESSION DEPENDENCY
# ============================================================================

async def get_current_user(session_token: Optional[str] = Cookie(None)):
    """Dependency to get current logged-in user"""
    logger.info(f"session token received:{session_token}")
    if not session_token:
    
        return None
    
    user = validate_session(session_token)
    logger.info(f"Validated user: {user}")
    return user


async def require_auth(user: Optional[dict] = Depends(get_current_user)):
    """Dependency to require authentication"""
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user


# ============================================================================
# LOGGING FUNCTIONS (Your existing functions)
# ============================================================================

def get_log_filename():
    """Get today's log filename"""
    today = datetime.now().strftime("%Y-%m-%d")
    return LOGS_DIR / f"{today}.txt"


def write_log(log_message: str):
    """Write log message to today's log file"""
    try:
        log_file = get_log_filename()
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(log_message + "\n")
    except Exception as e:
        logger.error(f"Error writing to log file: {str(e)}")


def get_client_ip(request: Request) -> str:
    """Extract client IP address from request"""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    
    real_ip = request.headers.get("X-Real-IP")
    if real_ip:
        return real_ip
    
    if request.client:
        return request.client.host
    
    return "Unknown"


def log_page_access(ip: str, page: str):
    """Log page access"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: {page}"
    write_log(log_message)


def log_dictation(ip: str, duration_seconds: float, result_text: str):
    """Log dictation session"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    minutes = int(duration_seconds // 60)
    seconds = int(duration_seconds % 60)
    duration_str = f"{minutes}m {seconds}s" if minutes > 0 else f"{seconds}s"
    
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Dictation | Duration: {duration_str}"
    write_log(log_message)


def log_discussion_summary_record(ip: str, mode: str, summary_length: str, filename: str, status: str, result_text: str = ""):
    """Log Discussion Summary with RECORD"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    if mode == "Summary":
        mode_text = f"Summary ({summary_length})"
    else:
        mode_text = mode
    
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Discussion Summary [RECORD] | Mode: {mode_text} | File: {filename} | Status: {status}"
    write_log(log_message)


def log_discussion_summary_upload(ip: str, mode: str, summary_length: str, filename: str, status: str, result_text: str = ""):
    """Log Discussion Summary with UPLOAD"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    if mode == "Summary":
        mode_text = f"Summary ({summary_length})"
    else:
        mode_text = mode
    
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Discussion Summary [UPLOAD] | Mode: {mode_text} | File: {filename} | Status: {status}"
    write_log(log_message)

# ============================================================================
# SECTION 1 — ADD NEW LOG FUNCTIONS
# Location: After your existing log functions (log_discussion_summary_upload, etc.)
#          BEFORE job_metadata = {}
# ============================================================================

def log_meeting_queries_access(ip: str, username: str):
    """Log Meeting Queries page access"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | User: {username}"
    write_log(log_message)


def log_session_selected_for_query(ip: str, username: str, session_name: str):
    """Log when user selects a session for querying"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: Session Selected | Session: {session_name} | User: {username}"
    write_log(log_message)


def log_task_selected_for_query(ip: str, username: str, task_name: str, session_count: int):
    """Log when user selects a task for querying"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: Task Selected | Task: {task_name} | Sessions Selected: {session_count} | User: {username}"
    write_log(log_message)


def log_question_asked(ip: str, username: str, mode: str, context: str, question: str):
    """Log when user asks a question"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # Truncate question if too long
    question_display = question[:100] + "..." if len(question) > 100 else question
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: Question Asked | Mode: {mode} | Context: {context} | Question: {question_display} | User: {username}"
    write_log(log_message)


def log_answer_generated(ip: str, username: str, mode: str, matched_sessions: str, status: str):
    """Log answer generation result"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: Answer Generated | Mode: {mode} | Matched Sessions: {matched_sessions} | Status: {status} | User: {username}"
    write_log(log_message)


def log_global_summary_viewed(ip: str, username: str, session_name: str):
    """Log when user views global summary"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: Global Summary Viewed | Session: {session_name} | User: {username}"
    write_log(log_message)


def log_no_global_summary_found(ip: str, username: str, session_name: str):
    """Log when global summary doesn't exist for selected session"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Meeting Queries | Action: No Global Summary | Session: {session_name} | User: {username}"
    write_log(log_message)


def log_global_summary_auto_generated(ip: str, username: str, session_name: str, result_count: int):
    """Log when global summary is auto-generated after meeting"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = f"IP: {ip} | Timestamp: {timestamp} | Page: Discussion Summary | Action: Global Summary Auto-Generated | Session: {session_name} | Results: {result_count} | User: {username}"
    write_log(log_message)

# Store job metadata temporarily to link with results
job_metadata = {}


# ============================================================================
# AUTHENTICATION ROUTES
# ============================================================================

@app.get("/login", response_class=HTMLResponse)
async def login_page(request: Request):
    """Serve the login page"""
    client_ip = get_client_ip(request)
    log_page_access(client_ip, "Login Page")
    
    html_content = """
    <!DOCTYPE html>
    <html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #fff;
        }
        .login-container {
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border-radius: 25px;
            padding: 50px 60px;
            text-align: center;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
            max-width: 400px;
            width: 90%;
        }
        h1 {
            color: #fff;
            margin-bottom: 10px;
            font-size: 2em;
        }
        p.subtitle {
            color: #e0e0e0;
            font-size: 1.1em;
            margin-bottom: 35px;
        }
        .form-group {
            margin-bottom: 25px;
            text-align: left;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #fff;
        }
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            border: none;
            border-radius: 8px;
            font-size: 1em;
            background: rgba(255, 255, 255, 0.9);
            box-sizing: border-box;
        }
        input:focus {
            outline: 2px solid #ffeb3b;
        }
        button {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: 600;
            background: linear-gradient(135deg, #ffeb3b 0%, #ffc107 100%);
            color: #333;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
        }
        .error {
            background: rgba(255, 82, 82, 0.9);
            color: white;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: none;
        }
        .success {
            background: rgba(76, 175, 80, 0.9);
            color: white;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: none;
        }
        footer {
            margin-top: 30px;
            color: #eaeaea;
            font-size: 0.85em;
        }
    </style>
    </head>
    <body>
        <div class="login-container">
            <h1></h1>
            <p class="subtitle">You Can Login With RCNET Username & Password here</p>
            
            <div id="error-message" class="error"></div>
            <div id="success-message" class="success"></div>
            
            <form id="login-form">
                <div class="form-group">
                    <label for="username">PIS Number / Username</label>
                    <input type="text" id="username" name="username" required autofocus>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" id="login-btn">Login</button>
            </form>
            
            <footer>
                <p></p>
                <p></p>
            </footer>
        </div>
        
        <script>
            const form = document.getElementById('login-form');
            const errorDiv = document.getElementById('error-message');
            const successDiv = document.getElementById('success-message');
            const loginBtn = document.getElementById('login-btn');
            
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const username = document.getElementById('username').value;
                const password = document.getElementById('password').value;
                
                // Hide messages
                errorDiv.style.display = 'none';
                successDiv.style.display = 'none';
                
                // Disable button
                loginBtn.disabled = true;
                loginBtn.textContent = 'Authenticating...';
                
                try {
                    const formData = new FormData();
                    formData.append('username', username);
                    formData.append('password', password);
                    
                    const response = await fetch('/authenticate', {
                        method: 'POST',
                        body: formData,
                        credentials: "include"
                        
                    });
                    console.log(response)
                    const data = await response.json();
                    
                    if (response.ok) {
                        successDiv.textContent = 'Login successful! ...';
                        successDiv.style.display = 'block';
                        setTimeout(() => {
                            window.location.href = '/';
                        }, 1000);
                    } else {
                        
                        errorDiv.textContent = data.error || 'Authentication failed';
                        errorDiv.style.display = 'block';
                        loginBtn.disabled = false;
                        loginBtn.textContent = 'Login';
                    }
                } catch (error) {
                    errorDiv.textContent = 'username or password incorrect';
                    errorDiv.style.display = 'block';
                    loginBtn.disabled = false;
                    loginBtn.textContent = 'Login';
                }
            });
        </script>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)


@app.post("/authenticate")
async def authenticate(
    request: Request,
    username: str = Form(...),
    password: str = Form(...)
):
    """Authenticate user via LDAP and create session"""
    client_ip = get_client_ip(request)
    
    # Clean expired sessions
    cleanup_expired_sessions()
    
    # Authenticate via LDAP
    success, display_name = authenticate_local_user(username, password, client_ip)
    
    if success:
        # Create session
        session_token = create_session(username, display_name, client_ip)
        
        # Log successful login
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_message = f"IP: {client_ip} | Timestamp: {timestamp} | Page: AD Login Success | User: {username} ({display_name})"
        write_log(log_message)
        
        # Create redirect response and set cookie
        response = JSONResponse(content= {
            "success":True,
            "message":"login Successful",
            "redirect":"/"
        })
        response.set_cookie(
            key="session_token",
            value=session_token,
            httponly=True,
            secure=False,  # Set to True in production
            samesite="lax",
           
            path="/"
        )
        
        return response
    else:
        # Log failed login
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_message = f"IP: {client_ip} | Timestamp: {timestamp} | Page: AD Login Failed | User: {username} | Reason: {display_name}"
        write_log(log_message)
        
        # Redirect back to login with error message
        from urllib.parse import quote
        error_msg = quote(display_name)
        return RedirectResponse(
            url=f"/login?error={error_msg}",
            status_code=303
        )

@app.get("/logout")
async def logout(
    response: Response,
    request: Request,
    session_token: Optional[str] = Cookie(None)
):
    """Logout user and clear session"""
    client_ip = get_client_ip(request)
    
    if session_token:
        user = validate_session(session_token)
        if user:
            # Log logout
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_message = f"IP: {client_ip} | Timestamp: {timestamp} | Page: Logout | User: {user['username']}"
            write_log(log_message)
        
        # Delete session
        delete_session(session_token)
    
    # Clear cookie
    response.delete_cookie(key="session_token")
    
    return RedirectResponse(url="/login", status_code=303)

# ============================================================================
# PROTECTED HTML ROUTES
# ============================================================================

@app.get("/", response_class=HTMLResponse)
async def serve_index(request: Request, user: dict = Depends(require_auth)):
    """Serve the index.html - PROTECTED"""
    try:
        client_ip = get_client_ip(request)
        log_page_access(client_ip, f"Index (Home) - User: {user['username']}")
        
        
        with open("index.html", "r", encoding="utf-8") as f:
            html_content = f.read()
        
        # Inject user info and logout button
        user_info_html = f"""
        <div style="position: fixed; top: 20px; right: 20px; background: rgba(255,255,255,0.9); 
                    padding: 10px 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);
                    z-index: 1000;">
            <span style="color: #333; font-weight: 600;">Welcome, {user['display_name']}</span>
            <a href="/logout" style="margin-left: 15px; color: #667eea; text-decoration: none; 
                                     font-weight: 600;">Logout</a>
        </div>
        """
        html_content = html_content.replace("</body>", f"{user_info_html}</body>")
        
        return HTMLResponse(content=html_content)
    except FileNotFoundError:
        return HTMLResponse(
            content="<h1>Error: index.html not found</h1>",
            status_code=404
        )


@app.get("/Dictation.html", response_class=HTMLResponse)
async def serve_audio_assistant(request: Request, user: dict = Depends(require_auth)):
    """Serve the Dictation page - PROTECTED"""
    try:
        client_ip = get_client_ip(request)
        log_page_access(client_ip, f"Dictation - User: {user['username']}")
        
        with open("Dictation.html", "r", encoding="utf-8") as f:
            html_content = f.read()
        
        # Inject user info
        user_info_html = f"""
        <div style="position: fixed; top: 20px; right: 20px; background: rgba(255,255,255,0.9); 
                    padding: 10px 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);
                    z-index: 1000;">
            <span style="color: #333; font-weight: 600;">{user['display_name']}</span>
            <a href="/logout" style="margin-left: 15px; color: #667eea; text-decoration: none; 
                                     font-weight: 600;">Logout</a>
        </div>
        """
        html_content = html_content.replace("</body>", f"{user_info_html}</body>")
        
        return HTMLResponse(content=html_content)
    except FileNotFoundError:
        return HTMLResponse(
            content="<h1>Error: Dictation.html not found</h1>",
            status_code=404
        )


@app.get("/Discussion_Summary.html", response_class=HTMLResponse)
async def serve_meeting_minutes(request: Request, user: dict = Depends(require_auth)):
    """Serve the Discussion Summary page - PROTECTED"""
    try:
        client_ip = get_client_ip(request)
        log_page_access(client_ip, f"Discussion Summary - User: {user['username']}")
        
        with open("Discussion_Summary.html", "r", encoding="utf-8") as f:
            html_content = f.read()
        
        # Inject user info
        user_info_html = f"""
        <div style="position: fixed; top: 20px; right: 20px; background: rgba(255,255,255,0.9); 
                    padding: 10px 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);
                    z-index: 1000;">
            <span style="color: #333; font-weight: 600;">{user['display_name']}</span>
            <a href="/logout" style="margin-left: 15px; color: #667eea; text-decoration: none; 
                                     font-weight: 600;">Logout</a>
        </div>
        """
        html_content = html_content.replace("</body>", f"{user_info_html}</body>")
        
        return HTMLResponse(content=html_content)
    except FileNotFoundError:
        return HTMLResponse(
            content="<h1>Error: Discussion_Summary.html not found</h1>",
            status_code=404
        )

@app.get("/Meeting_Queries.html", response_class=HTMLResponse)
async def serve_meeting_queries(request: Request, user: dict = Depends(require_auth)):
    """Serve the Meeting Queries page - PROTECTED"""
    try:
        client_ip = get_client_ip(request)
        log_meeting_queries_access(client_ip, user['username'])

        with open("Meeting_Queries.html", "r", encoding="utf-8") as f:
            html_content = f.read()

        # Inject user info
        user_info_html = f"""
        <div style="position: fixed; top: 20px; right: 20px; background: rgba(255,255,255,0.9); 
                    padding: 10px 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.2);
                    z-index: 1000;">
            <span style="color: #333; font-weight: 600;">{user['display_name']}</span>
            <a href="/logout" style="margin-left: 15px; color: #667eea; text-decoration: none; 
                                     font-weight: 600;">Logout</a>
        </div>
        """
        html_content = html_content.replace("</body>", f"{user_info_html}</body>")

        return HTMLResponse(content=html_content)
    except FileNotFoundError:
        return HTMLResponse(
            content="<h1>Error: Meeting_Queries.html not found</h1>",
            status_code=404
        )
@app.get("/health")
async def health_check(request: Request):
    """Health check endpoint - PUBLIC"""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            response = await client.get(f"{GPU_SERVER_URL}/health")
            gpu_status = response.json()
            
            return {
                "web_server": "healthy",
                "gpu_server": gpu_status,
                "auth_system": "active"
            }
    except Exception as e:
        return {
            "web_server": "healthy",
            "gpu_server": f"unreachable: {str(e)}",
            "auth_system": "active"
        }


# ============================================================================
# API ROUTES (PROTECTED)
# ============================================================================

@app.post("/process_audio")
async def process_audio(
        request: Request,
        user: dict = Depends(require_auth),
        file: UploadFile = File(...),
        mode: str = Form(...),
        summary_length: str = Form(default="Medium"),
        is_upload: bool = Form(default=False),
        session_id: Optional[str] = Form(default=None),  # ← was Form(...), now optional
        result_order: Optional[str] = Form(default=None)  # ← was Form(...), now optional
):
    """Forward audio processing to GPU server - PROTECTED"""
    client_ip = get_client_ip(request)
    
    try:
        # Read file content
        file_content = await file.read()
        
        # Prepare multipart form data
        files = {"file": (file.filename, file_content, file.content_type)}
        data = {
            "mode": mode,
            "summary_length": summary_length,
        }

        # Only include session context when it exists (Discussion Summary page)
        # Dictation page does NOT send session_id — that is intentional
        if session_id:
            data["session_id"] = session_id
            data["result_order"] = result_order or "1"
        
        # Forward to GPU server
        async with httpx.AsyncClient(timeout=300.0) as client:
            response = await client.post(
                f"{GPU_SERVER_URL}/process_audio",
                files=files,
                data=data
            )
            
            if response.status_code != 200:
                raise HTTPException(status_code=response.status_code, detail=response.text)
            
            result = response.json()
            job_id = result.get("job_id", "unknown")
            
            # Store metadata for this job
            job_metadata[job_id] = {
                "ip": client_ip,
                "mode": mode,
                "summary_length": summary_length,
                "filename": file.filename,
                "is_upload": is_upload,
                "username": user['username']
            }
            
            return result
            
    except httpx.RequestError as e:
        logger.error(f"Error forwarding to GPU server: {str(e)}")
        
        # Log failure
        if is_upload:
            log_discussion_summary_upload(client_ip, mode, summary_length, file.filename, "FAILED", "")
        else:
            log_discussion_summary_record(client_ip, mode, summary_length, file.filename, "FAILED", "")
        
        raise HTTPException(status_code=503, detail=f"GPU server unreachable: {str(e)}")
    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/job_status/{job_id}")
async def get_job_status(request: Request, job_id: str, user: dict = Depends(require_auth)):
    """Check job status and log results - PROTECTED"""
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            response = await client.get(f"{GPU_SERVER_URL}/job_status/{job_id}")
            
            if response.status_code == 404:
                raise HTTPException(status_code=404, detail="Job not found")
            
            result = response.json()
            
            # Log completed jobs
            if result.get("status") == "completed" and job_id in job_metadata:
                metadata = job_metadata[job_id]
                result_text = result.get("result", "")
                
                if metadata["is_upload"]:
                    log_discussion_summary_upload(
                        metadata["ip"],
                        metadata["mode"],
                        metadata["summary_length"],
                        metadata["filename"],
                        "SUCCESS",
                        result_text
                    )
                else:
                    log_discussion_summary_record(
                        metadata["ip"],
                        metadata["mode"],
                        metadata["summary_length"],
                        metadata["filename"],
                        "SUCCESS",
                        result_text
                    )
                
                # Clean up metadata
                del job_metadata[job_id]
            
            # Log failed jobs
            elif result.get("status") == "error" and job_id in job_metadata:
                metadata = job_metadata[job_id]
                
                if metadata["is_upload"]:
                    log_discussion_summary_upload(
                        metadata["ip"],
                        metadata["mode"],
                        metadata["summary_length"],
                        metadata["filename"],
                        "FAILED",
                        ""
                    )
                else:
                    log_discussion_summary_record(
                        metadata["ip"],
                        metadata["mode"],
                        metadata["summary_length"],
                        metadata["filename"],
                        "FAILED",
                        ""
                    )
                
                # Clean up metadata
                del job_metadata[job_id]
            
            return result
            
    except httpx.RequestError as e:
        logger.error(f"Error checking job status: {str(e)}")
        raise HTTPException(status_code=503, detail=f"GPU server unreachable: {str(e)}")


@app.post("/log_dictation")
async def log_dictation_endpoint(
    request: Request,
    user: dict = Depends(require_auth),
    duration: float = Form(...),
    result: str = Form(...)
):
    """Endpoint for frontend to log dictation sessions - PROTECTED"""
    client_ip = get_client_ip(request)
    log_dictation(client_ip, duration, result)
    return {"status": "logged"}


@app.post("/global_summary")
async def generate_global_summary(
    request: Request,
    summary_request: GlobalSummaryRequest,
    user: dict = Depends(require_auth)
):

    """Forward global summary request to GPU server - PROTECTED"""
    try:
        async with httpx.AsyncClient(timeout=300.0) as client:
            response = await client.post(
                f"{GPU_SERVER_URL}/global_summary",
                json={
                    "texts":      summary_request.texts,
                    "session_id": summary_request.session_id  # pass through for server-side save
                }
            )
            
            if response.status_code != 200:
                raise HTTPException(status_code=response.status_code, detail=response.text)
            
            return response.json()
            
    except httpx.RequestError as e:
        logger.error(f"Error generating global summary: {str(e)}")
        raise HTTPException(status_code=503, detail=f"GPU server unreachable: {str(e)}")


# ============================================================================
# TASK MANAGEMENT PROXY ENDPOINTS
# ============================================================================

@app.post("/create_task")
async def create_task_proxy(request: Request, user: dict = Depends(require_auth)):
    """Forward create task request to GPU server"""
    try:
        body = await request.json()
        body['username'] = user['username']  # Inject authenticated username

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(f"{GPU_SERVER_URL}/create_task", json=body)
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error creating task: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/user_tasks")
async def get_user_tasks_proxy(request: Request, user: dict = Depends(require_auth)):
    """Get all tasks for current user"""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f"{GPU_SERVER_URL}/user_tasks/{user['username']}")
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error getting tasks: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/task_sessions/{task_id}")
async def get_task_sessions_proxy(request: Request, task_id: str, user: dict = Depends(require_auth)):
    """Get all sessions for a specific task"""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f"{GPU_SERVER_URL}/task_sessions/{task_id}")
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error getting task sessions: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/delete_task")
async def delete_task_proxy(request: Request, user: dict = Depends(require_auth)):
    """Forward delete task request"""
    try:
        body = await request.json()
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(f"{GPU_SERVER_URL}/delete_task", json=body)
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error deleting task: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/rename_task")
async def rename_task_proxy(request: Request, user: dict = Depends(require_auth)):
    """Forward rename task request to GPU server"""
    try:
        body = await request.json()
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(f"{GPU_SERVER_URL}/rename_task", json=body)
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error renaming task: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

def log_text_upload(ip: str, username: str, session_name: str, text_length: int):
    """Log when user uploads a manual text document as a session"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_message = (
        f"IP: {ip} | Timestamp: {timestamp} | Page: Discussion Summary [TEXT UPLOAD] | "
        f"Session: {session_name} | Characters: {text_length} | User: {username} | Status: SUCCESS"
    )
    write_log(log_message)


@app.post("/create_discussion_session")
async def create_discussion_session_proxy(request: Request, user: dict = Depends(require_auth)):
    """Forward create session request with task support"""
    try:
        form_data = await request.form()

        # Build form data for GPU server
        data = {
            'username': user['username'],
            'task_id': form_data.get('task_id'),
            'venue': form_data.get('venue'),
            'agenda': form_data.get('agenda')
        }

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{GPU_SERVER_URL}/create_session",
                data=data
            )
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error creating session: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/save_text_result")
async def save_text_result_proxy(
        request: Request,
        user: dict = Depends(require_auth)
):
    """
    Auth-checked proxy — forwards a manually pasted meeting text
    directly to gpu2.py for DB storage with no model inference.
    """
    try:
        client_ip = get_client_ip(request)
        body = await request.json()

        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.post(
                f"{GPU_SERVER_URL}/save_text_result",
                json=body
            )

        if response.status_code != 200:
            raise HTTPException(
                status_code=response.status_code,
                detail=response.text
            )

        data = response.json()

        # Log the upload with session name (passed from frontend) and text length
        log_text_upload(
            client_ip,
            user['username'],
            body.get('session_name', body.get('session_id', 'unknown')[:8]),
            len(body.get('result_text', ''))
        )

        return data

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Error in save_text_result proxy: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/discussion_session/{session_id}")
async def get_discussion_session_proxy(request: Request, session_id: str, user: dict = Depends(require_auth)):
    """Forward get session request"""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f"{GPU_SERVER_URL}/session/{session_id}")
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error getting session: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/rename_discussion_session")
async def rename_session_proxy(request: Request, user: dict = Depends(require_auth)):
    """Forward rename session request"""
    try:
        body = await request.json()
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(f"{GPU_SERVER_URL}/rename_session", json=body)
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error renaming session: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/delete_discussion_session")
async def delete_discussion_session_proxy(request: Request, user: dict = Depends(require_auth)):
    """Forward delete session request"""
    try:
        body = await request.json()
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(f"{GPU_SERVER_URL}/delete_discussion_session", json=body)
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error deleting session: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
        
        
@app.post("/export_screen")
async def export_screen_proxy(
        request: Request,
        user: dict = Depends(require_auth)
):
    """
    Auth-checked proxy — forwards screen data to gpu.py and
    streams the .docx back to the browser.
    """
    try:
        body = await request.json()

        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                f"{GPU_SERVER_URL}/export_screen",
                json=body
            )

        if response.status_code == 400:
            raise HTTPException(status_code=400, detail="No results to export.")

        if response.status_code != 200:
            raise HTTPException(
                status_code=response.status_code,
                detail="Export failed on processing server"
            )

        content_disp = response.headers.get(
            "content-disposition",
            'attachment; filename="Meeting_Summary.docx"'
        )

        return Response(
            content=response.content,
            media_type=(
                "application/vnd.openxmlformats-officedocument"
                ".wordprocessingml.document"
            ),
            headers={"Content-Disposition": content_disp}
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Export proxy error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# SECTION  —  Q&A PROXY ENDPOINTS
# ============================================================================

@app.get("/check_global_summary/{session_id}")
async def check_global_summary_proxy(
        request: Request,
        session_id: str,
        user: dict = Depends(require_auth)
):
    """Check if global summary exists for session"""
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f"{GPU_SERVER_URL}/check_global_summary/{session_id}")
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error checking global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/get_global_summary/{session_id}")
async def get_global_summary_proxy(
        request: Request,
        session_id: str,
        user: dict = Depends(require_auth)
):
    """Get global summary for session"""
    try:
        client_ip = get_client_ip(request)

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(f"{GPU_SERVER_URL}/get_global_summary/{session_id}")

            if response.status_code == 200:
                data = response.json()
                # Log viewing if successful
                log_global_summary_viewed(client_ip, user['username'], session_id[:8])
                return data
            elif response.status_code == 404:
                log_no_global_summary_found(client_ip, user['username'], session_id[:8])
                raise HTTPException(status_code=404, detail="Global summary not found")
            else:
                raise HTTPException(status_code=response.status_code, detail=response.text)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Error getting global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ask_question")
async def ask_question_proxy(
        request: Request,
        user: dict = Depends(require_auth)
):
    """Forward Q&A request to GPU server"""
    try:
        client_ip = get_client_ip(request)
        body = await request.json()

        question = body.get('question', '')
        session_ids = body.get('session_ids', [])
        context_name = body.get('context_name', 'Unknown')

        # Determine mode
        mode = "Single Session" if len(session_ids) == 1 else "Multi Session"

        # Log question asked
        log_question_asked(client_ip, user['username'], mode, context_name, question)

        async with httpx.AsyncClient(timeout=210.0) as client:
            response = await client.post(
                f"{GPU_SERVER_URL}/ask_question",
                json=body
            )

            if response.status_code == 200:
                data = response.json()

                # Extract matched session names for logging
                source_sessions = data.get('source_sessions', [])
                matched_names = ", ".join([s['session_name'] for s in source_sessions])

                # Log successful answer generation
                log_answer_generated(client_ip, user['username'], mode, matched_names, "SUCCESS")

                return data
            else:
                log_answer_generated(client_ip, user['username'], mode, "N/A", "FAILED")
                raise HTTPException(status_code=response.status_code, detail=response.text)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Error in Q&A: {str(e)}")
        log_answer_generated(get_client_ip(request), user['username'], "Unknown", "N/A", "ERROR")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/save_global_summary_auto")
async def save_global_summary_auto_proxy(
        request: Request,
        user: dict = Depends(require_auth)
):
    """Save global summary after auto-generation"""
    try:
        body = await request.json()

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.post(
                f"{GPU_SERVER_URL}/save_global_summary",
                json=body
            )
            return response.json()
    except Exception as e:
        logger.error(f"✗ Error saving global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
# ============================================================================
# EXCEPTION HANDLERS
# ============================================================================

@app.exception_handler(401)
async def unauthorized_handler(request: Request, exc: HTTPException):
    """Redirect unauthorized requests to login page"""
    if request.url.path.startswith("/authenticate") or request.url.path.startswith("/login"):
        return JSONResponse(
            status_code=401,
            content={"error": "Unauthorized"}
        )
    print("user unauthorised access", flush=True)
    return RedirectResponse(url="/login", status_code=303)


# ============================================================================
# SERVER STARTUP
# ============================================================================

if __name__ == "__main__":
    port = 8000
    
    # Initialize authentication database
    initialize_auth_database()
    cleanup_expired_sessions()
    
    # Log server startup
    startup_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    startup_log = f"========== SERVER STARTUP | Timestamp: {startup_time} | Port: {port} | AUTH ENABLED =========="
    write_log(startup_log)
    
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=port,
        #ssl_keyfile="./private.key",
        #ssl_certfile="./combined.crt"
    )
