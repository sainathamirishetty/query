from fastapi import FastAPI, File, UploadFile, BackgroundTasks, Form, HTTPException, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
from contextlib import asynccontextmanager
import torch
import uvicorn
import uuid
import shutil
from datetime import datetime
from pathlib import Path
import logging
import os
import sqlite3
from threading import Lock

from transformers.models.voxtral.modeling_voxtral import VoxtralForConditionalGeneration
from transformers import AutoProcessor


import httpx  # For Ollama API calls

import json  # CRITICAL - Don't forget this
from typing import Optional, List




from scipy.io import wavfile
from export_utils import build_docx
import asyncio
import io
from fastapi.responses import StreamingResponse




logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
RECORDINGS_DIR = Path("./server_recordings")
RECORDINGS_DIR.mkdir(exist_ok=True)

# Q&A Configuration - Ollama
OLLAMA_SERVER_URL = "http://0.0.0.0:12345"
OLLAMA_MODEL = "gpt-oss:20b"  # The model name as shown in `ollama list` Development server




# Database
DB_FILE = Path("./sessions.db")
db_lock = Lock()

model = None
processor = None
device = "cuda" if torch.cuda.is_available() else "cpu"
jobs = {}


def initialize_database():
    """Initialize database for task hierarchy"""
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    # Tasks table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            task_id TEXT PRIMARY KEY,
            username TEXT NOT NULL,
            task_name TEXT NOT NULL,
            agenda TEXT DEFAULT '' ,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL
        )
    """)

    # Sessions table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            session_id TEXT PRIMARY KEY,
            task_id TEXT,
            username TEXT NOT NULL,
            session_name TEXT NOT NULL,
            session_number INTEGER,
            meeting_date TEXT,
            meeting_time TEXT,
            venue TEXT,
            agenda TEXT,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            FOREIGN KEY (task_id) REFERENCES tasks(task_id) ON DELETE CASCADE
        )
    """)

    # Results table
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS results (
            result_id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            result_order INTEGER NOT NULL,
            mode TEXT NOT NULL,
            summary_length TEXT,
            result_text TEXT NOT NULL,
            created_at DATETIME NOT NULL,
            FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE CASCADE
        )
    """)
    # Results table
    cursor.execute("""
            CREATE TABLE IF NOT EXISTS global_summaries (
                summary_id TEXT PRIMARY KEY,
                session_id TEXT NOT NULL,
                summary_text TEXT NOT NULL,
                is_auto_generated BOOLEAN DEFAULT 1,
                created_at DATETIME NOT NULL,
                is_latest BOOLEAN DEFAULT 1,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE CASCADE
            )
        """)
    conn.commit()
    conn.close()
    logger.info("✓ Database initialized")


def create_task(username: str, task_name: str, agenda: str = '') -> str:
    """Create a new task"""
    task_id = str(uuid.uuid4())
    now = datetime.now().isoformat()

    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO tasks (task_id, username, task_name, agenda, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (task_id, username, task_name, agenda.strip(), now, now))
        conn.commit()
        conn.close()

    logger.info(f"✓ Created task: {task_name}")
    return task_id


def get_user_tasks(username: str):
    """Get all tasks for a user"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT task_id, task_name, agenda, created_at, updated_at
            FROM tasks WHERE username = ?
            ORDER BY created_at DESC
        """, (username,))

        tasks = []
        for row in cursor.fetchall():
            task_id, task_name, agenda, created_at, updated_at = row

            cursor.execute("SELECT COUNT(*) FROM sessions WHERE task_id = ?", (task_id,))
            session_count = cursor.fetchone()[0]

            tasks.append({
                'task_id': task_id,
                'task_name': task_name,
                'agenda': agenda or '',
                'session_count': session_count,
                'created_at': created_at,
                'updated_at': updated_at
            })

        conn.close()
    return tasks


def get_task_sessions(task_id: str):
    """Get sessions for a task"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT session_id, session_name, session_number, meeting_date,
                   meeting_time, venue, agenda, created_at
            FROM sessions WHERE task_id = ?
            ORDER BY session_number ASC
        """, (task_id,))

        sessions = []
        for row in cursor.fetchall():
            sid, name, num, date, time, venue, agenda, created = row

            cursor.execute("SELECT COUNT(*) FROM results WHERE session_id = ?", (sid,))
            result_count = cursor.fetchone()[0]

            sessions.append({
                'session_id': sid,
                'session_name': name,
                'session_number': num,
                'meeting_date': date,
                'meeting_time': time,
                'venue': venue,
                'agenda': agenda,
                'result_count': result_count,
                'created_at': created,
                'task_id': task_id
            })

        conn.close()
    return sessions


def delete_task(task_id: str):
    """Delete task and all data"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        cursor.execute("""
            DELETE FROM results
            WHERE session_id IN (SELECT session_id FROM sessions WHERE task_id = ?)
        """, (task_id,))

        # ── NEW: also delete global summaries for sessions in this task ──
        cursor.execute("""
            DELETE FROM global_summaries
            WHERE session_id IN (SELECT session_id FROM sessions WHERE task_id = ?)
        """, (task_id,))

        cursor.execute("DELETE FROM sessions WHERE task_id = ?", (task_id,))
        cursor.execute("DELETE FROM tasks WHERE task_id = ?", (task_id,))

        conn.commit()
        conn.close()

    logger.info(f"✓ Deleted task")
    return True

def rename_task(task_id: str, new_name: str) -> bool:
    """Rename a task"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        cursor.execute("SELECT task_id FROM tasks WHERE task_id = ?", (task_id,))
        if not cursor.fetchone():
            conn.close()
            return False

        cursor.execute("""
            UPDATE tasks SET task_name = ?, updated_at = ?
            WHERE task_id = ?
        """, (new_name.strip(), datetime.now().isoformat(), task_id))

        conn.commit()
        conn.close()

    logger.info(f"✓ Renamed task {task_id[:8]} to: {new_name}")
    return True

def create_session(username: str, task_id: str, venue: str = None, agenda: str = None):
    """Create a session"""
    session_id = str(uuid.uuid4())
    now = datetime.now()
    now_iso = now.isoformat()

    # Get next session number
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("SELECT MAX(session_number) FROM sessions WHERE task_id = ?", (task_id,))
        result = cursor.fetchone()
        session_number = (result[0] if result and result[0] else 0) + 1
        conn.close()

    # Generate name
    months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
              'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    month = months[now.month - 1]
    day = now.day
    hour = now.hour % 12 if now.hour % 12 != 0 else 12
    minute = now.minute
    ampm = 'AM' if now.hour < 12 else 'PM'

    timestamp = f"{month} {day}, {hour}:{minute:02d} {ampm}"

    venue = venue.strip() if venue else ""
    agenda = agenda.strip() if agenda else ""

    if agenda and venue:
        session_name = f"{agenda} - {venue} - {timestamp}"
    elif agenda:
        session_name = f"{agenda} - {timestamp}"
    elif venue:
        session_name = f"{venue} - {timestamp}"
    else:
        session_name = f"Session {session_number} - {timestamp}"

    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO sessions (
                session_id, task_id, username, session_name, session_number,
                meeting_date, meeting_time, venue, agenda, created_at, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            session_id, task_id, username, session_name, session_number,
            now.strftime('%Y-%m-%d'), now.strftime('%H:%M:%S'),
            venue, agenda, now_iso, now_iso
        ))
        conn.commit()
        conn.close()

    logger.info(f"✓ Created session: {session_name}")

    return {
        'session_id': session_id,
        'session_name': session_name,
        'session_number': session_number
    }


def rename_session(session_id: str, new_name: str):
    """Rename session"""
    import re

    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        cursor.execute("SELECT session_name FROM sessions WHERE session_id = ?", (session_id,))
        result = cursor.fetchone()
        if not result:
            conn.close()
            return False

        current_name = result[0]
        timestamp_pattern = r' - ([A-Z][a-z]{2} \d{1,2}, \d{1,2}:\d{2} [AP]M)$'
        timestamp_match = re.search(timestamp_pattern, current_name)

        if timestamp_match:
            timestamp = timestamp_match.group(1)
            final_name = f"{new_name} - {timestamp}"
        else:
            final_name = new_name

        cursor.execute("""
            UPDATE sessions SET session_name = ?, updated_at = ?
            WHERE session_id = ?
        """, (final_name, datetime.now().isoformat(), session_id))

        conn.commit()
        conn.close()

    logger.info(f"✓ Renamed session")
    return True


def delete_session(session_id: str):
    """Delete session"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        cursor.execute("DELETE FROM results WHERE session_id = ?", (session_id,))
        cursor.execute("DELETE FROM global_summaries WHERE session_id = ?", (session_id,))  # ← NEW
        cursor.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))

        conn.commit()
        conn.close()

    logger.info(f"✓ Deleted session")
    return True


def get_session_details(session_id: str):
    """Get session with results"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT session_id, session_name, meeting_date, meeting_time,
                   venue, agenda, created_at
            FROM sessions WHERE session_id = ?
        """, (session_id,))

        result = cursor.fetchone()
        if not result:
            conn.close()
            return None

        session_data = {
            'session_id': result[0],
            'session_name': result[1],
            'meeting_date': result[2],
            'meeting_time': result[3],
            'venue': result[4],
            'agenda': result[5],
            'created_at': result[6]
        }

        cursor.execute("""
            SELECT result_id, result_order, mode, summary_length,
                   result_text, created_at
            FROM results WHERE session_id = ?
            ORDER BY result_order ASC
        """, (session_id,))

        results = []
        for row in cursor.fetchall():
            results.append({
                'result_id': row[0],
                'result_order': row[1],
                'mode': row[2],
                'summary_length': row[3],
                'result_text': row[4],
                'created_at': row[5]
            })

        session_data['results'] = results

        # ── NEW: also load the latest global summary (stored in a separate table) ──
        cursor.execute("""
            SELECT summary_id, summary_text, created_at
            FROM global_summaries
            WHERE session_id = ? AND is_latest = 1
            ORDER BY created_at DESC
            LIMIT 1
        """, (session_id,))
        gs_row = cursor.fetchone()
        if gs_row:
            # Append it as a synthetic result so the frontend can display it
            # result_order = 99999 so it always appears last
            session_data['global_summary'] = {
                'summary_id':  gs_row[0],
                'summary_text': gs_row[1],
                'created_at':  gs_row[2]
            }
        else:
            session_data['global_summary'] = None

        conn.close()

    return session_data


def save_result(session_id: str, result_order: int, mode: str,
                result_text: str, summary_length: str = None):
    """Save result to database"""
    result_id = str(uuid.uuid4())
    now = datetime.now().isoformat()

    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO results (
                result_id, session_id, result_order, mode,
                summary_length, result_text, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (result_id, session_id, result_order, mode, summary_length, result_text, now))

        conn.commit()
        conn.close()

    logger.info(f"✓ Saved result #{result_order}")
    return result_id



def save_global_summary_to_db(session_id: str, summary_text: str, is_auto: bool = True):
    """Save global summary to database"""
    summary_id = str(uuid.uuid4())
    now = datetime.now().isoformat()

    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        # Mark previous summaries as not latest
        cursor.execute("""
            UPDATE global_summaries 
            SET is_latest = 0 
            WHERE session_id = ?
        """, (session_id,))


        cursor.execute("""
            INSERT INTO global_summaries 
            (summary_id, session_id, summary_text, is_auto_generated, created_at, is_latest)
            VALUES (?, ?, ?, ?, ?, 1)
        """, (summary_id, session_id, summary_text, is_auto, now))

        conn.commit()
        conn.close()

    logger.info(f"✓ Saved global summary for session {session_id[:8]}...")
    return summary_id

def get_global_summary_from_db(session_id: str):
    """Get latest global summary for a session"""
    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        cursor.execute("""
            SELECT summary_id, summary_text, created_at
            FROM global_summaries
            WHERE session_id = ? AND is_latest = 1
            ORDER BY created_at DESC
            LIMIT 1
        """, (session_id,))

        result = cursor.fetchone()
        conn.close()

        if result:
            return {
                'summary_id': result[0],
                'summary_text': result[1],
                'created_at': result[2]
            }
        return None

def get_all_summaries_for_sessions(session_ids: List[str]):
    """Fetch global summaries for a list of session IDs — no embedding, direct fetch"""
    summaries = []

    with db_lock:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()

        for session_id in session_ids:
            cursor.execute("""
                SELECT s.session_id, s.session_name, gs.summary_text
                FROM global_summaries gs
                JOIN sessions s ON gs.session_id = s.session_id
                WHERE gs.session_id = ? AND gs.is_latest = 1
                ORDER BY gs.created_at DESC
                LIMIT 1
            """, (session_id,))

            result = cursor.fetchone()
            if result:
                summaries.append({
                    'session_id': result[0],
                    'session_name': result[1],
                    'summary_text': result[2]
                })
            else:
                logger.warning(f"⚠ No global summary found for session {session_id[:8]}")

        conn.close()

    return summaries

async def generate_qa_answer(context_summaries: List[dict], question: str) -> dict:
    """
    Generate answer using Ollama with per-session SOURCE citations.
    Each session is labelled SOURCE 1, SOURCE 2, ... in the prompt.
    The model is instructed to cite [SOURCE N] after every statement.
    Returns: { "answer": str, "cited_sources": [{"source_label", "session_id", "session_name"}] }
    """

    # Build labelled context block
    context_block = ""
    source_map = {}  # "SOURCE N" -> {session_id, session_name}

    for idx, summary in enumerate(context_summaries, 1):
        label = f"SOURCE {idx}"
        source_map[label] = {
            "session_id":   summary["session_id"],
            "session_name": summary["session_name"]
        }
        context_block += (
            f"\n\n[{label}] — Session: {summary['session_name']}\n"
            f"{'-' * 60}\n"
            f"{summary['summary_text']}\n"
        )

    # System prompt with citation instructions
    system_prompt = (
        "You are a meeting summary analyst. "
        "You will be given summaries from multiple meeting sessions, each labelled [SOURCE N]. "
        "Answer the user's question using ONLY the provided meeting summaries. "
        "Do NOT use any outside knowledge. "
        "If the answer is not in any summary, say exactly: "
        "\"This was not discussed in the provided meeting summaries.\" "
        "\n\n"
        "CITATION RULES (VERY IMPORTANT):\n"
        "- After EVERY sentence or fact in your answer, add the citation in brackets, e.g. [SOURCE 1] or [SOURCE 2].\n"
        "- If a fact comes from multiple sources, cite all of them: [SOURCE 1][SOURCE 2].\n"
        "- Use ONLY the [SOURCE N] format for citations. Do not use footnotes or other formats.\n"
        "- Be concise, factual, and direct.\n"
    )

    user_prompt = (
        f"MEETING SUMMARIES:\n"
        f"{context_block}\n\n"
        f"QUESTION: {question}\n\n"
        f"ANSWER (remember to cite [SOURCE N] after every statement):"
    )

    try:
        async with httpx.AsyncClient(timeout=180.0) as client:
            response = await client.post(
                f"{OLLAMA_SERVER_URL}/api/chat",
                json={
                    "model": OLLAMA_MODEL,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user",   "content": user_prompt}
                    ],
                    "stream": False,
                    "options": {
                        "temperature":    0.1,
                        "num_predict":    768,
                        "repeat_penalty": 1.1
                    }
                }
            )

        if response.status_code != 200:
            raise Exception(f"Ollama returned status {response.status_code}: {response.text}")

        result = response.json()
        answer = result["message"]["content"].strip()

        # Parse which SOURCE labels actually appear in the answer
        import re
        cited_labels = set(re.findall(r'\[SOURCE\s+(\d+)\]', answer, re.IGNORECASE))

        cited_sources = []
        for num_str in sorted(cited_labels, key=lambda x: int(x)):
            label = f"SOURCE {num_str}"
            if label in source_map:
                cited_sources.append({
                    "source_label": label,
                    "session_id":   source_map[label]["session_id"],
                    "session_name": source_map[label]["session_name"]
                })

        logger.info(f"✓ Ollama answer generated — cited sources: {[s['source_label'] for s in cited_sources]}")

        return {
            "answer":        answer,
            "cited_sources": cited_sources,
            "all_sources":   [
                {
                    "source_label": f"SOURCE {idx}",
                    "session_id":   s["session_id"],
                    "session_name": s["session_name"]
                }
                for idx, s in enumerate(context_summaries, 1)
            ]
        }

    except httpx.ConnectError:
        raise Exception(
            f"Cannot connect to Ollama at {OLLAMA_SERVER_URL}. "
            f"Make sure Ollama is running and OLLAMA_HOST=0.0.0.0 is set."
        )
    except httpx.TimeoutException:
        raise Exception("Ollama timed out after 180 seconds.")
    except Exception as e:
        logger.error(f"✗ Ollama error: {str(e)}")
        raise

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global model, processor


    try:
        # Set offline mode FIRST
        os.environ['TRANSFORMERS_OFFLINE'] = '1'
        os.environ['HF_DATASETS_OFFLINE'] = '1'

        # Initialize database first
        initialize_database()

        logger.info("=" * 70)
        logger.info("Loading AI models...")
        logger.info("=" * 70)

        # Load Voxtral (existing - unchanged)
        repo_id = "/Users/vishnukumarkudidela/Desktop/workspace/ASR/models/Voxtral-Mini-3B-2507"
        processor = AutoProcessor.from_pretrained(repo_id)
        model = VoxtralForConditionalGeneration.from_pretrained(
            repo_id, torch_dtype=torch.bfloat16, device_map=device
        )
        logger.info(f"✓ Voxtral loaded successfully on {device}")

        logger.info(f"✓ Q&A will use Ollama at {OLLAMA_SERVER_URL} with model '{OLLAMA_MODEL}'")

        logger.info("=" * 70)

    except Exception as e:
        logger.error(f"✗ Failed to load models: {e}")
        raise

    yield

    # Shutdown
    logger.info("Shutting down GPU server...")

app = FastAPI(title="DEAIS GPU Server", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)



class GlobalSummaryRequest(BaseModel):
    texts: List[str]
    session_id: Optional[str] = None   # if provided → save to DB internally


class ExportResultItem(BaseModel):
    mode: str
    summaryLength: Optional[str] = None
    result: str


class ExportRequest(BaseModel):
    date: Optional[str] = ''
    time: Optional[str] = ''
    venue: Optional[str] = ''
    agenda: Optional[str] = ''
    results: List[ExportResultItem] = []

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "model_loaded": model is not None,
        "device": device,
        "timestamp": datetime.now().isoformat()
    }

@app.post("/process_audio")
async def process_audio(
        background_tasks: BackgroundTasks,
        file: UploadFile = File(...),
        mode: str = Form(...),
        summary_length: str = Form(default="Medium"),
        session_id: Optional[str] = Form(default=None),  # ← was Form(...), now optional
        result_order: Optional[int] = Form(default=None)  # ← was Form(...), now optional
):
    """Process uploaded audio file for transcription, summary, or action points"""
    if not model or not processor:
        raise HTTPException(status_code=503, detail="Model not loaded")

    # Validate mode
    valid_modes = ["Transcription", "Summary", "Action Points"]
    if mode not in valid_modes:
        raise HTTPException(status_code=400, detail=f"Invalid mode. Must be one of {valid_modes}")

    # For Summary/Action Points, session_id is required
    # For Transcription (Dictation page), session_id is NOT required
    if mode in ["Summary", "Action Points"] and not session_id:
        raise HTTPException(
            status_code=400,
            detail="session_id is required for Summary and Action Points modes"
        )

    job_id = str(uuid.uuid4())
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    file_path = RECORDINGS_DIR / f"{timestamp}_{mode.replace(' ', '_')}_{file.filename}"

    # Save uploaded file
    #print(type(file.file),flush=True)
    try:
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            """ret_val=read_wav_and_sum(file_path)
            
            # Create job entry
            jobs[job_id] = {
            "job_id": job_id,
            "status": "processing",
            "mode": mode,
            "summary_length": summary_length if mode == "Summary" else None,
            "result": None,
            "error": None,
            "created_at": datetime.now().isoformat(),
            "completed_at": None,
            "file_path": str(file_path),
            "session_id": session_id,
            "result_order": result_order
            }
            
            # Update job status
            
            jobs[job_id]["status"] = "completed"
            jobs[job_id]["result"] = " ... "
            jobs[job_id]["completed_at"] = datetime.now().isoformat()
            if ret_val<60:
                return {
                "job_id": job_id,
                "status": "processing",
                "mode": mode,
                "message": f"Processing low voice audio with mode: {mode}"
                }"""

            
        logger.info(f" Saved audio file: {file_path}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save file: {str(e)}")

    # Create job entry
    jobs[job_id] = {
        "job_id": job_id,
        "status": "processing",
        "mode": mode,
        "summary_length": summary_length if mode == "Summary" else None,
        "result": None,
        "error": None,
        "created_at": datetime.now().isoformat(),
        "completed_at": None,
        "file_path": str(file_path)
    }

    # Process in background
    background_tasks.add_task(process_audio_task, job_id, str(file_path), mode, summary_length, session_id, result_order)
    logger.info(f" Job {job_id} created — Mode: {mode}, Session: {session_id or 'N/A (Dictation)'}")

    return {
        "job_id": job_id,
        "status": "processing",
        "mode": mode,
        "message": f"Processing audio with mode: {mode}"
    }


async def process_audio_task(job_id: str, file_path: str, mode: str, summary_length: str, session_id: Optional[str], result_order: Optional[int]):
    """Background task to process audio"""
    try:
        logger.info(f" Starting processing for job {job_id} - Mode: {mode}")

        if mode == "Transcription":
            logger.info(f" Processing Transcription for {job_id}")
            inputs = processor.apply_transcription_request(
                language="en",
                audio=file_path,
                model_id="/Users/vishnukumarkudidela/Desktop/workspace/ASR/models/Voxtral-Mini-3B-2507"
            )
            inputs = inputs.to(device, dtype=torch.bfloat16)
            outputs = model.generate(**inputs, max_new_tokens=4096,temperature=0.1,top_p=0.85,repetition_penalty=1.1)
            decoded = processor.batch_decode(
                outputs[:, inputs.input_ids.shape[1]:],
                skip_special_tokens=True
            )
            result = f"[TRANSCRIPTION]\n\n{decoded[0]}"

        elif mode == "Summary":
            logger.info(f" Processing Summary ({summary_length}) for {job_id}")
            instructions = {
                "Short": "generate a short, concise summary",
                "Medium": "generate a medium-length, detailed summary",
                "Long": "generate a comprehensive, long-form summary"
            }
            instruction = instructions.get(summary_length, instructions["Medium"])

            conversation = [{
                "role": "user",
                "content": [{
                    "type": "text",
                    "text": (
                        f"You are a helpful assistant that works in summarizer mode.don't react to any conversations or questions in the audio.Summarize audio to text only "
                        f"After listening to the audio, please understand the total audio, "
                        f"then {instruction} that should be organised topic-wise, with clear things, "
                        f"within the audio by utilizing entire input audio. "
                        f"Do not use numbered lists (1., 2., 3., etc.). Use only the ➤ symbol for all summary modes.\n"
                        f"Don't go for hallucinations and extended sentences which are not in the audio. "
                        f"Keep the summary within provided audio only."
                    )
                }]
            }, {
                "role": "user",
                "content": [{"type": "audio", "path": file_path}]
            }]

            inputs = processor.apply_chat_template(conversation)
            inputs = inputs.to(device, dtype=torch.bfloat16)
            outputs = model.generate(**inputs, max_new_tokens=2048,temperature=0.1,top_p=0.85,do_sample=False,repetition_penalty=1.1)
            decoded = processor.batch_decode(
                outputs[:, inputs.input_ids.shape[1]:],
                skip_special_tokens=True
            )
            result = f"[SUMMARY - {summary_length}]\n\n{decoded[0]}"

        elif mode == "Action Points":
            logger.info(f" Processing Action Points for {job_id}")
            conversation = [{
                "role": "user",
                "content": [{
                    "type": "text",
                    "text": (
                        "You are a helpful assistant that works in action points extraction mode. "
                        "After listening the audio, extract all key action points. "
                        "Each action point should clearly state:\n"
                        "- The task or decision\n"
                        "- Who is responsible\n"
                        "- The deadline or timeline (if mentioned)\n"
                        "- Any dependencies or resources needed\n"
                        "Present the output using the ➤ symbol for each action point instead of numbers.\n"
                        "Format each action point exactly like this:\n"
                        "➤ Task/Decision: [description]\n"
                        "  • Responsible: [person]\n"
                        "  • Deadline: [date/timeline]\n\n"
                        "Do not use numbered lists (1., 2., 3., etc.). Use only the ➤ symbol for each action point.\n"
                        "If audio has no action points, then give the text you understood clearly."
                    )
                }]
            }, {
                "role": "user",
                "content": [{"type": "audio", "path": file_path}]
            }]

            inputs = processor.apply_chat_template(conversation)
            inputs = inputs.to(device, dtype=torch.bfloat16)
            outputs = model.generate(**inputs, max_new_tokens=2048,temperature=0.1,top_p=0.85,do_sample=False,repetition_penalty=1.1)
            decoded = processor.batch_decode(
                outputs[:, inputs.input_ids.shape[1]:],
                skip_special_tokens=True
            )
            result = f"[ACTION POINTS]\n\n{decoded[0]}"

        # ── Save to database ONLY for Discussion Summary (session_id present) ──
        # Dictation page (Transcription mode, no session_id) → skip DB save
        result_id = None  # always initialize — Dictation mode won't assign it
        if session_id and result_order is not None:
            result_id = save_result(
                session_id,
                result_order,
                mode,
                result,
                summary_length if mode == "Summary" else None
            )
            logger.info(f" Saved result to DB for session {session_id[:8]}...")
        else:
            logger.info(f" Transcription result — no DB save (Dictation mode)")
        # Update job status
        jobs[job_id]["status"] = "completed"
        jobs[job_id]["result"] = result
        if result_id:
            jobs[job_id]["result_id"] = result_id
        jobs[job_id]["completed_at"] = datetime.now().isoformat()

        logger.info(f" Job {job_id} completed successfully - Mode: {mode}")

    except Exception as e:
        logger.error(f" Job {job_id} failed: {str(e)}")
        jobs[job_id]["status"] = "error"
        jobs[job_id]["error"] = str(e)
        jobs[job_id]["completed_at"] = datetime.now().isoformat()

    finally:
        # AUTOMATICALLY DELETE THE AUDIO FILE AFTER PROCESSING
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                logger.info(f" Auto-deleted temporary audio file: {file_path}")
        except Exception as e:
            logger.error(f"Failed to delete file {file_path}: {str(e)}")


@app.get("/job_status/{job_id}")
async def get_job_status(job_id: str):
    """Check the status of a processing job"""
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")

    job_data = jobs[job_id].copy()
    # Don't send file_path to client
    if "file_path" in job_data:
        del job_data["file_path"]

    return job_data


@app.post("/global_summary")
async def generate_global_summary(request: GlobalSummaryRequest):
    """Generate a global summary from multiple text results"""
    if not model or not processor:
        raise HTTPException(status_code=503, detail="Model not loaded")

    if not request.texts:
        raise HTTPException(status_code=400, detail="No texts provided")

    try:
        # Filter out transcriptions, keep only summaries and action points
        filtered = [t for t in request.texts if not t.strip().startswith("[TRANSCRIPTION]")]

        if not filtered:
            raise HTTPException(status_code=400, detail="No valid summaries or action points to process")

        combined = "\n\n".join(filtered)

        conversation = [{
            "role": "user",
            "content": [{
                "type": "text",
                "text": (
                    "You are an expert meeting summarizer. Your task is to create a comprehensive global summary "
                    "from multiple meeting segments.\n\n"

                    "INSTRUCTIONS:\n"
                    "1. Read and analyze all the provided text segments carefully\n"
                    "2. Identify and group related topics across all segments\n"
                    "3. Create a cohesive, well-organized summary that covers ALL topics discussed\n"
                    "4. Maintain chronological flow when relevant\n"
                    "5. Preserve important details, decisions, and discussions\n"
                    "6. Remove redundancies while keeping unique information from each segment\n"
                    "7. don't repeat the sentences keep as unique\n\n"

                    "OUTPUT STRUCTURE:\n"
                    "- Start with an 'OVERVIEW' section (2-3 sentences about the overall meeting)\n"
                    "- Organize content by TOPICS with clear headings\n"
                    "- Under each topic, provide key points and discussions\n"
                    "- Include a 'KEY DECISIONS' section if any decisions were made\n"
                    "- End with 'ACTION ITEMS' section if action points exist\n\n"

                    "IMPORTANT GUIDELINES:\n"
                    "- Do NOT add information not present in the original text\n"
                    "- Do NOT miss any important topics, even if briefly mentioned\n"
                    "- Use clear, professional language\n"
                    "- Be concise but comprehensive\n"
                    "- don't repeat the sentences keep as unique\n"
                    "- don't add action points twice in global summary\n"
                    "- If a topic appears in multiple segments, consolidate it intelligently\n\n"

                    f"TEXT TO SUMMARIZE:\n\n{combined}"
                )
            }]
        }]

        inputs = processor.apply_chat_template(conversation)
        inputs = inputs.to(device, dtype=torch.bfloat16)
        outputs = model.generate(**inputs, max_new_tokens=4096,temperature=0.1,top_p=0.85,do_sample=False,repetition_penalty=1.1)
        decoded = processor.batch_decode(
            outputs[:, inputs.input_ids.shape[1]:],
            skip_special_tokens=True
        )

        global_summary_text = decoded[0]

        logger.info("✓ Global summary generated successfully")

        # ── Save to DB immediately if session_id was provided ──────────────
        # This means saving does NOT depend on the browser staying alive.
        # Whether the user clicks Back or the tab crashes — summary is safe.
        saved_to_db = False
        if request.session_id:
            try:
                save_global_summary_to_db(
                    request.session_id,
                    global_summary_text,
                    is_auto=True
                )
                saved_to_db = True
                logger.info(f"✓ Global summary auto-saved to DB for session {request.session_id[:8]}")
            except Exception as save_err:
                logger.error(f"✗ Failed to auto-save global summary: {save_err}")
                # Don't raise — still return the generated text to browser

        return {
            "status":       "success",
            "global_summary": global_summary_text,
            "saved_to_db":  saved_to_db
        }

    except Exception as e:
        logger.error(f"✗ Global summary generation failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# TASK/SESSION ENDPOINTS
# ============================================================================

@app.post("/create_task")
async def create_task_endpoint(request: Request):
    try:
        body = await request.json()
        username = body.get('username')
        task_name = body.get('task_name')
        agenda = body.get('agenda', '')

        if not username or not task_name:
            raise HTTPException(status_code=400, detail="username and task_name required")

        task_id = create_task(username, task_name, agenda)
        return {"status": "success", "task_id": task_id, "task_name": task_name}
    except Exception as e:
        logger.error(f"✗ Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/user_tasks/{username}")
async def get_user_tasks_endpoint(username: str):
    try:
        tasks = get_user_tasks(username)
        for task in tasks:
            task['sessions'] = get_task_sessions(task['task_id'])
        return {"status": "success", "tasks": tasks}
    except Exception as e:
        logger.error(f"✗ Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/delete_task")
async def delete_task_endpoint(request: Request):
    try:
        body = await request.json()
        task_id = body.get('task_id')
        if not task_id:
            raise HTTPException(status_code=400, detail="task_id required")
        delete_task(task_id)
        return {"status": "success"}
    except Exception as e:
        logger.error(f"✗ Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/rename_task")
async def rename_task_endpoint(request: Request):
    try:
        body = await request.json()
        task_id = body.get('task_id')
        new_name = body.get('new_name', '').strip()

        if not task_id or not new_name:
            raise HTTPException(status_code=400, detail="task_id and new_name are required")

        success = rename_task(task_id, new_name)
        if not success:
            raise HTTPException(status_code=404, detail="Task not found")

        return {"status": "success", "task_id": task_id, "new_name": new_name}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Error renaming task: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/task_sessions/{task_id}")
async def get_task_sessions_endpoint(task_id: str):
    try:
        sessions = get_task_sessions(task_id)
        return {"status": "success", "sessions": sessions}
    except Exception as e:
        logger.error(f"✗ Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/create_session")
async def create_session_endpoint(
        username: str = Form(...),
        task_id: str = Form(...),
        venue: str = Form(None),
        agenda: str = Form(None)
):
    try:
        session_data = create_session(username, task_id, venue, agenda)
        return {"status": "success", **session_data}
    except Exception as e:
        logger.error(f"✗ Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/save_text_result")
async def save_text_result_endpoint(request: Request):
    """
    Save a manually pasted meeting document as a result directly to DB.
    No model inference — no job queue — no polling needed.
    The text is stored exactly like an audio-processed result
    so the rest of the pipeline (global summary, Q&A) works identically.
    """
    try:
        body = await request.json()
        session_id   = body.get('session_id', '').strip()
        result_text  = body.get('result_text', '').strip()
        result_order = int(body.get('result_order', 1))
        mode         = body.get('mode', 'Summary')          # always "Summary"
        summary_length = body.get('summary_length', 'Document')

        if not session_id:
            raise HTTPException(status_code=400, detail="session_id is required")
        if not result_text:
            raise HTTPException(status_code=400, detail="result_text cannot be empty")

        result_id = save_result(
            session_id,
            result_order,
            mode,
            result_text,
            summary_length
        )

        logger.info(f"✓ Text result saved directly — session {session_id[:8]}  order {result_order}")

        return {
            "status":    "success",
            "result_id": result_id,
            "mode":      mode,
            "result":    result_text
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Error saving text result: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/session/{session_id}")
async def get_session_endpoint(session_id: str):
    try:
        session = get_session_details(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        return {"status": "success", "session": session}
    except Exception as e:
        logger.error(f"✗ Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/rename_session")
async def rename_session_endpoint(request: Request):
    try:
        body = await request.json()
        session_id = body.get('session_id')
        new_name = body.get('new_name')

        if not session_id or not new_name:
            raise HTTPException(status_code=400, detail="session_id and new_name required")

        success = rename_session(session_id, new_name)
        if not success:
            raise HTTPException(status_code=404, detail="Session not found")
        return {"status": "success"}
    except Exception as e:
        logger.error(f"✗ Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/delete_discussion_session")
async def delete_session_endpoint(request: Request):
    try:
        body = await request.json()
        session_id = body.get('session_id')
        if not session_id:
            raise HTTPException(status_code=400, detail="session_id required")
        delete_session(session_id)
        return {"status": "success"}
    except Exception as e:
        logger.error(f"✗ Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/check_global_summary/{session_id}")
async def check_global_summary_exists(session_id: str):
    """Check if global summary exists for a session"""
    try:
        summary = get_global_summary_from_db(session_id)
        return {
            "status": "success",
            "exists": summary is not None
        }
    except Exception as e:
        logger.error(f"✗ Error checking global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/get_global_summary/{session_id}")
async def get_global_summary_endpoint(session_id: str):
    """Get global summary for a session"""
    try:
        summary = get_global_summary_from_db(session_id)

        if not summary:
            raise HTTPException(status_code=404, detail="Global summary not found")

        return {
            "status": "success",
            "summary": summary
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Error getting global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ask_question")
async def ask_question_endpoint(request: Request):
    """Answer question using global summaries of selected sessions, with per-session citations."""
    try:
        body        = await request.json()
        question    = body.get('question', '').strip()
        session_ids = body.get('session_ids', [])

        if not question:
            raise HTTPException(status_code=400, detail="Question is required")
        if not session_ids:
            raise HTTPException(status_code=400, detail="At least one session_id is required")

        logger.info(f"📝 Q&A — Question: '{question[:60]}' — Sessions: {len(session_ids)}")

        # Fetch global summaries (maintains order = SOURCE 1, SOURCE 2, ...)
        context = get_all_summaries_for_sessions(session_ids)

        if not context:
            raise HTTPException(
                status_code=404,
                detail=(
                    "No global summaries found for the selected sessions. "
                    "Please generate summaries first in Discussion Summary."
                )
            )

        logger.info(f"✓ Fetched {len(context)} global summary(ies) — sending to Ollama with citations")

        result = await generate_qa_answer(context, question)

        return {
            "status":         "success",
            "answer":         result["answer"],
            # cited_sources = only the sessions actually cited in the answer
            "source_sessions": [
                {"session_id": s["session_id"], "session_name": s["session_name"]}
                for s in result["cited_sources"]
            ] if result["cited_sources"] else [
                # Fallback: return all sources if none were explicitly cited
                {"session_id": s["session_id"], "session_name": s["session_name"]}
                for s in result["all_sources"]
            ]
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Q&A Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/save_global_summary")
async def save_global_summary_endpoint(request: Request):
    """Save global summary to database (called after auto-generation)"""
    try:
        body = await request.json()
        session_id = body.get('session_id')
        summary_text = body.get('summary_text')
        is_auto = body.get('is_auto_generated', True)

        if not session_id or not summary_text:
            raise HTTPException(status_code=400, detail="session_id and summary_text required")

        summary_id = save_global_summary_to_db(session_id, summary_text, is_auto)

        return {
            "status": "success",
            "summary_id": summary_id
        }
    except Exception as e:
        logger.error(f"✗ Error saving global summary: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/export_screen")
async def export_screen_endpoint(payload: ExportRequest):
    """
    Receives current screen data (input fields + allResults array),
    builds a formatted .docx and streams it to the browser.
    No database queries — purely from what the user sees on screen.
    """
    if not payload.results:
        raise HTTPException(status_code=400, detail="No results to export.")

    screen_data = {
        'date':    payload.date   or '',
        'time':    payload.time   or '',
        'venue':   payload.venue  or '',
        'agenda':  payload.agenda or '',
        'results': [
            {
                'mode':          r.mode,
                'summaryLength': r.summaryLength,
                'result':        r.result,
            }
            for r in payload.results
        ]
    }

    # Run docx build in thread — it's CPU-bound, keep event loop free
    loop = asyncio.get_event_loop()
    try:
        docx_bytes = await loop.run_in_executor(None, build_docx, screen_data)
    except Exception as e:
        logger.error(f"✗ DOCX build error: {e}")
        raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")

    # Build a clean filename from agenda or venue
    hint = (payload.agenda or payload.venue or 'Meeting').strip()
    safe = "".join(c if c.isalnum() or c in ' -_' else '_' for c in hint)
    safe = safe.strip().replace(' ', '_')[:50]
    filename = f"Meeting_Summary_{safe}.docx"

    logger.info(f"✓ Exported: {filename}  ({len(docx_bytes):,} bytes)")

    return StreamingResponse(
        io.BytesIO(docx_bytes),
        media_type=(
            "application/vnd.openxmlformats-officedocument"
            ".wordprocessingml.document"
        ),
        headers={"Content-Disposition": f'attachment; filename="{filename}"'}
    )
# ============================================================================
# SERVER STARTUP
# ============================================================================

if __name__ == "__main__":
    port = 8001
    server_ip = "127.0.0.1"
    
    print(f"\n{'=' * 70}")
    print(f"GPU Processing Server")
    print(f"{'=' * 70}")
    print(f" Server Address:      http://{server_ip}:{port}")
    print(f" Health Check:        http://{server_ip}:{port}/health")
    print(f" Device:              {device}")
    print(f" Recordings Dir:      {RECORDINGS_DIR.absolute()}")
    print(f"{'=' * 70}")
    print(f" Loading AI model... (this may take 1-2 minutes)")
    print(f"{'=' * 70}\n")
    
    uvicorn.run(app, host=server_ip, port=port)
