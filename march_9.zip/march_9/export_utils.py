"""
export_utils.py
───────────────
Generates a well-formatted, fully editable .docx from screen data.
No PDF, no DB queries — purely from what the user sees on screen.

Install once on the GPU server machine:
    pip install python-docx
"""

import io
import re
import logging
from datetime import datetime

from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

logger = logging.getLogger(__name__)

# ── Brand colours (matches your app) ─────────────────────────────────────────
C_HEADING  = RGBColor(0x76, 0x4B, 0xA2)   # deep purple  #764ba2
C_PRIMARY  = RGBColor(0x66, 0x7E, 0xEA)   # purple-blue  #667eea
C_BODY     = RGBColor(0x1F, 0x2D, 0x3D)   # near-black
C_GREY     = RGBColor(0x99, 0x99, 0x99)   # footer grey
C_WHITE    = RGBColor(0xFF, 0xFF, 0xFF)
HEX_HEADER_BG = "764BA2"   # table header cell fill
HEX_ROW_BG    = "EEF2FF"   # info table label fill
HEX_BORDER    = "C4B5E8"   # subtle purple border


# =============================================================================
# LOW-LEVEL XML HELPERS
# =============================================================================

def _set_cell_fill(cell, hex_color: str):
    """Background fill for a table cell."""
    tc   = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shd  = OxmlElement('w:shd')
    shd.set(qn('w:val'),   'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'),  hex_color)
    # remove any existing shd first
    for existing in tcPr.findall(qn('w:shd')):
        tcPr.remove(existing)
    tcPr.append(shd)


def _set_cell_borders(cell, hex_color: str = HEX_BORDER, size: int = 4):
    """Thin coloured border on all sides of a cell."""
    tc   = cell._tc
    tcPr = tc.get_or_add_tcPr()
    borders = OxmlElement('w:tcBorders')
    for side in ('top', 'left', 'bottom', 'right'):
        el = OxmlElement(f'w:{side}')
        el.set(qn('w:val'),   'single')
        el.set(qn('w:sz'),    str(size))
        el.set(qn('w:space'), '0')
        el.set(qn('w:color'), hex_color)
        borders.append(el)
    for existing in tcPr.findall(qn('w:tcBorders')):
        tcPr.remove(existing)
    tcPr.append(borders)


def _set_cell_margins(cell, top=80, bottom=80, left=120, right=120):
    """Inner padding for a table cell."""
    tc   = cell._tc
    tcPr = tc.get_or_add_tcPr()
    mar  = OxmlElement('w:tcMar')
    for side, val in (('top', top), ('bottom', bottom),
                      ('left', left), ('right', right)):
        el = OxmlElement(f'w:{side}')
        el.set(qn('w:w'),    str(val))
        el.set(qn('w:type'), 'dxa')
        mar.append(el)
    for existing in tcPr.findall(qn('w:tcMar')):
        tcPr.remove(existing)
    tcPr.append(mar)


def _paragraph_bottom_border(paragraph, hex_color: str = "667EEA", size: int = 6):
    """Draws a thin coloured line under a paragraph — used as section divider."""
    pPr    = paragraph._p.get_or_add_pPr()
    pBdr   = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'),   'single')
    bottom.set(qn('w:sz'),    str(size))
    bottom.set(qn('w:space'), '4')
    bottom.set(qn('w:color'), hex_color)
    pBdr.append(bottom)
    for existing in pPr.findall(qn('w:pBdr')):
        pPr.remove(existing)
    pPr.append(pBdr)


def _set_row_height(row, height_twips: int = 400):
    """Set exact row height in twips (1 inch = 1440 twips)."""
    trPr = row._tr.get_or_add_trPr()
    trHeight = OxmlElement('w:trHeight')
    trHeight.set(qn('w:val'),  str(height_twips))
    trHeight.set(qn('w:hRule'), 'atLeast')
    trPr.append(trHeight)


# =============================================================================
# STYLE HELPERS
# =============================================================================

def _run(paragraph, text: str, bold=False, italic=False,
         size_pt=10, color: RGBColor = None, font='Arial') -> None:
    """Add a styled run to an existing paragraph."""
    run = paragraph.add_run(text)
    run.font.name   = font
    run.font.size   = Pt(size_pt)
    run.bold        = bold
    run.italic      = italic
    if color:
        run.font.color.rgb = color


def _heading_paragraph(doc, text: str, level: int = 1) -> object:
    """
    Section heading with bottom border divider.
    level 1 → large (MEETING INFORMATION, RESULTS)
    level 2 → medium (individual result titles)
    """
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after  = Pt(4)

    if level == 1:
        _run(p, text, bold=True, size_pt=12, color=C_HEADING)
        _paragraph_bottom_border(p, hex_color="764BA2", size=8)
    else:
        _run(p, text, bold=True, size_pt=10.5, color=C_PRIMARY)
        _paragraph_bottom_border(p, hex_color="667EEA", size=4)

    return p


def _body_paragraph(doc, text: str,
                    justify=True, size_pt=10, space_after=4) -> object:
    """Standard body text paragraph."""
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY if justify else WD_ALIGN_PARAGRAPH.LEFT
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.space_before = Pt(0)
    _run(p, text, size_pt=size_pt, color=C_BODY)
    return p


def _bullet_paragraph(doc, text: str,
                      indent_level=0, size_pt=10) -> object:
    """
    Bullet item using proper Word list style (not unicode characters).
    indent_level 0 = main bullet (➤ lines)
    indent_level 1 = sub-bullet (• Responsible / • Deadline lines)
    """
    p = doc.add_paragraph(style='List Bullet')
    left_indent  = Inches(0.3 + indent_level * 0.25)
    hang_indent  = Inches(0.2)
    p.paragraph_format.left_indent     = left_indent
    p.paragraph_format.first_line_indent = -hang_indent
    p.paragraph_format.space_after      = Pt(3)
    p.paragraph_format.space_before     = Pt(1)
    _run(p, text, size_pt=size_pt, color=C_BODY)
    return p


def _spacer(doc, size_pt=6) -> object:
    p = doc.add_paragraph()
    p.paragraph_format.space_after  = Pt(size_pt)
    p.paragraph_format.space_before = Pt(0)
    return p


# =============================================================================
# CLEAN RESULT TEXT
# =============================================================================

def _clean(text: str) -> str:
    """Strip AI mode header tags like [SUMMARY - Short] from result text."""
    text = re.sub(
        r'^\[(?:SUMMARY[^\]]*|ACTION POINTS|TRANSCRIPTION|GLOBAL SUMMARY)\]\s*',
        '', text.strip()
    )
    text = re.sub(r'\*\*\*(.+?)\*\*\*', r'\1', text)
    text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
    text = re.sub(r'\*(.+?)\*', r'\1', text)
    text = re.sub(r'^#{1,6}\s*', '', text, flags=re.MULTILINE)
    text = re.sub(r'~~(.+?)~~', r'\1', text)
    return text.strip()


def _format_date(raw: str) -> str:
    for fmt in ('%Y-%m-%d',):
        try:
            return datetime.strptime(raw, fmt).strftime('%d %B %Y')
        except Exception:
            pass
    return raw or '—'


def _format_time(raw: str) -> str:
    for fmt in ('%H:%M', '%H:%M:%S'):
        try:
            return datetime.strptime(raw, fmt).strftime('%I:%M %p')
        except Exception:
            pass
    return raw or '—'


# =============================================================================
# MAIN — BUILD .DOCX
# =============================================================================

def build_docx(screen_data: dict) -> bytes:
    """
    Build a fully formatted, editable .docx from screen data.

    screen_data = {
        "date":    "2026-02-24",
        "time":    "10:30",
        "venue":   "Conference Room B",
        "agenda":  "Q1 Budget Review",
        "results": [
            { "mode": "Summary",       "summaryLength": "Short", "result": "..." },
            { "mode": "Action Points", "summaryLength": null,    "result": "..." },
            { "mode": "GLOBAL SUMMARY","summaryLength": null,    "result": "..." }
        ]
    }

    Returns raw bytes — stream directly to browser.
    """
    doc = Document()

    # ── Page setup: A4, 2.5 cm margins ───────────────────────────────────────
    for section in doc.sections:
        section.page_width    = Cm(21.0)
        section.page_height   = Cm(29.7)
        section.left_margin   = Cm(2.5)
        section.right_margin  = Cm(2.5)
        section.top_margin    = Cm(2.0)
        section.bottom_margin = Cm(2.0)

    # ── Default font for entire document ─────────────────────────────────────
    doc.styles['Normal'].font.name = 'Arial'
    doc.styles['Normal'].font.size = Pt(10)
    doc.styles['Normal'].font.color.rgb = C_BODY

    # ── Override built-in heading styles so TOC navigation works ─────────────
    for style_name, size, color in (
        ('Heading 1', 14, C_HEADING),
        ('Heading 2', 12, C_HEADING),
        ('Heading 3', 11, C_PRIMARY),
    ):
        try:
            st = doc.styles[style_name]
            st.font.name      = 'Arial'
            st.font.size      = Pt(size)
            st.font.color.rgb = color
            st.font.bold      = True
        except Exception:
            pass

    # =========================================================================
    # BLOCK 1 — TITLE BANNER
    # =========================================================================
    # if False:  # HIDDEN — remove this line to restore banner
    #     banner_tbl = doc.add_table(rows=1, cols=1)
    #     banner_tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    #     banner_tbl.style = 'Table Grid'
    #
    #     banner_cell = banner_tbl.rows[0].cells[0]
    #     banner_cell.width = Cm(16)
    #     _set_cell_fill(banner_cell, HEX_HEADER_BG)
    #     _set_cell_borders(banner_cell, hex_color=HEX_HEADER_BG)
    #     _set_cell_margins(banner_cell, top=160, bottom=100, left=200, right=200)
    #     _set_row_height(banner_tbl.rows[0], 600)
    #     banner_cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    #
    #     bp1 = banner_cell.paragraphs[0]
    #     bp1.alignment = WD_ALIGN_PARAGRAPH.CENTER
    #     _run(bp1, "DIRECTORATE OF EMBEDDED AI SYSTEMS (DEAIS) — RCI",
    #          bold=True, size_pt=13, color=C_WHITE)
    #
    #     bp2 = banner_cell.add_paragraph()
    #     bp2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    #     _run(bp2, "AI Based Speech Capture & Summarization System",
    #          italic=True, size_pt=10, color=RGBColor(0xDD, 0xCC, 0xFF))
    #
    #     _spacer(doc, 10)

    # =========================================================================
    # BLOCK 2 — MEETING INFORMATION TABLE
    # =========================================================================
    _heading_paragraph(doc, "MEETING INFORMATION", level=1)
    _spacer(doc, 4)

    date_val   = _format_date(screen_data.get('date',   ''))
    time_val   = _format_time(screen_data.get('time',   ''))
    venue_val  = screen_data.get('venue',  '').strip() or '—'
    agenda_val = screen_data.get('agenda', '').strip() or '—'

    info_rows = [
        ("Date",   date_val),
        ("Time",   time_val),
        ("Venue",  venue_val),
        ("Agenda", agenda_val),
    ]

    info_tbl = doc.add_table(rows=len(info_rows), cols=2)
    info_tbl.alignment = WD_TABLE_ALIGNMENT.LEFT
    info_tbl.style = 'Table Grid'

    for i, (label, value) in enumerate(info_rows):
        row   = info_tbl.rows[i]
        cells = row.cells
        _set_row_height(row, 380)

        # Label cell
        cells[0].width = Cm(3.0)
        _set_cell_fill(cells[0], HEX_ROW_BG)
        _set_cell_borders(cells[0], hex_color=HEX_BORDER)
        _set_cell_margins(cells[0])
        cells[0].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        lp = cells[0].paragraphs[0]
        lp.alignment = WD_ALIGN_PARAGRAPH.LEFT
        _run(lp, label, bold=True, size_pt=10, color=C_PRIMARY)

        # Value cell
        cells[1].width = Cm(13.0)
        _set_cell_borders(cells[1], hex_color=HEX_BORDER)
        _set_cell_margins(cells[1])
        cells[1].vertical_alignment = WD_ALIGN_VERTICAL.CENTER
        vp = cells[1].paragraphs[0]
        vp.alignment = WD_ALIGN_PARAGRAPH.LEFT
        _run(vp, value, size_pt=10, color=C_BODY)

    _spacer(doc, 12)

    # =========================================================================
    # BLOCK 3 — RESULTS
    # =========================================================================
    results = screen_data.get('results', [])

    if not results:
        _body_paragraph(doc, "No results available.")
    else:
        _heading_paragraph(doc, "RESULTS", level=1)

        for idx, item in enumerate(results, start=1):
            mode   = item.get('mode', '')
            length = item.get('summaryLength') or ''
            text   = item.get('result', '')

            # ── Result sub-heading ────────────────────────────────────────────
            if mode == 'Summary' and length:
                label = f"{idx}.  Summary  ({length})"
            elif mode == 'GLOBAL SUMMARY':
                label = f"{idx}.  Global Summary"
            elif mode == 'Action Points':
                label = f"{idx}.  Action Points"
            elif mode == 'Transcription':
                label = f"{idx}.  Transcription"
            else:
                label = f"{idx}.  {mode}" if mode else f"Result {idx}"

            _spacer(doc, 6)
            _heading_paragraph(doc, label, level=2)

            # ── Parse and render the result text ─────────────────────────────
            clean_text = _clean(text)
            lines      = clean_text.split('\n')

            for line in lines:
                stripped = line.strip()

                # Blank line → small spacer
                if not stripped:
                    _spacer(doc, 3)
                    continue

                # Main bullet  ➤ Task description
                if stripped.startswith('➤'):
                    content = stripped.lstrip('➤').strip()
                    _bullet_paragraph(doc, content, indent_level=0)

                # Standard bullet  •  or  -
                elif stripped.startswith('•') or re.match(r'^-\s', stripped):
                    content = stripped.lstrip('•-').strip()
                    _bullet_paragraph(doc, content, indent_level=0)

                # Sub-bullet (indented lines like "  • Responsible: ...")
                elif re.match(r'^\s{2,}[•\-]', line):
                    content = stripped.lstrip('•-').strip()
                    _bullet_paragraph(doc, content, indent_level=1)

                # ALL-CAPS section header inside result text (e.g. OVERVIEW, KEY DECISIONS)
                elif re.match(r'^[A-Z][A-Z\s\-:]{3,}$', stripped):
                    p = doc.add_paragraph()
                    p.paragraph_format.space_before = Pt(8)
                    p.paragraph_format.space_after  = Pt(3)
                    _run(p, stripped, bold=True, size_pt=10,
                         color=C_PRIMARY)

                # Normal body text
                else:
                    _body_paragraph(doc, stripped, justify=True)

            _spacer(doc, 6)

    # =========================================================================
    # BLOCK 4 — FOOTER
    # =========================================================================
    footer = doc.sections[0].footer
    fp     = footer.paragraphs[0]
    fp.clear()
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    _paragraph_bottom_border(fp, hex_color="C4B5E8", size=4)

    export_ts = datetime.now().strftime('%d %B %Y   %I:%M %p')
    _run(fp, f"Generated by DEAIS AI System  |  Exported: {export_ts}",
         size_pt=8, color=C_GREY)

    # ── Serialise ─────────────────────────────────────────────────────────────
    buf = io.BytesIO()
    doc.save(buf)
    buf.seek(0)
    return buf.read()
