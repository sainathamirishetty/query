@app.post("/ask_question")
async def ask_question_endpoint(request: Request):
    """Answer question from meeting context - Simplified per HOD requirements"""
    try:
        body = await request.json()
        question = body.get('question', '').strip()
        session_ids = body.get('session_ids', [])
        
        if not question:
            raise HTTPException(status_code=400, detail="Question is required")
        
        if not session_ids or len(session_ids) == 0:
            raise HTTPException(status_code=400, detail="At least one session required")
        
        logger.info(f"📝 Q&A Request - Question: '{question[:50]}...' - Sessions: {len(session_ids)}")
        
        # Fetch all selected session summaries (NO embedding matching)
        context = []
        
        with db_lock:
            conn = sqlite3.connect(DB_FILE)
            cursor = conn.cursor()
            
            for session_id in session_ids:
                # Get summary
                cursor.execute("""
                    SELECT summary_text
                    FROM global_summaries
                    WHERE session_id = ? AND is_latest = 1
                """, (session_id,))
                
                summary_result = cursor.fetchone()
                
                if not summary_result:
                    # Summary doesn't exist - skip this session
                    logger.warning(f"⚠ No global summary for session {session_id}")
                    continue
                
                # Get session name
                cursor.execute("""
                    SELECT session_name
                    FROM sessions
                    WHERE session_id = ?
                """, (session_id,))
                
                session_result = cursor.fetchone()
                session_name = session_result[0] if session_result else f"Session {session_id[:8]}"
                
                context.append({
                    'session_id': session_id,
                    'session_name': session_name,
                    'summary_text': summary_result[0],
                    'embedding': None
                })
            
            conn.close()
        
        if not context:
            raise HTTPException(
                status_code=404, 
                detail="No global summaries found for selected sessions"
            )
        
        logger.info(f"✓ Loaded {len(context)} summary(ies) - Sending ALL to Ollama")
        
        # Generate answer using Ollama (passes ALL summaries, no filtering)
        answer = await generate_qa_answer(context, question)
        
        # Attribution
        attribution = " + ".join([s['session_name'] for s in context])
        logger.info(f"✓ Answer generated from {len(context)} session(s)")
        
        return {
            "status": "success",
            "answer": answer,
            "source_sessions": [
                {
                    'session_id': s['session_id'],
                    'session_name': s['session_name']
                }
                for s in context
            ]
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"✗ Q&A Error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
